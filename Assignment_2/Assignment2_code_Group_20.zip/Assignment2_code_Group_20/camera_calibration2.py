import glob
import os

import cv2 as cv
import numpy as np
from utilities import (
    checkQuality,
    frame_extraction,
    linear_interpolation,
    select_corners,
    sharpen_image,
    automatic_chessboard_detection
)

# CONSTANTS
GRID_SHAPE = (6, 8)
CELL_SIZE = 115
FPS = 1
N_CAM = 4

# termination criteria
criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# Frame extraction
for cam_number in range(1, N_CAM + 1):

    video_path = f"data/cam{cam_number}/intrinsics.avi"
    output_folder = f"calibration/cam{cam_number}_calibration"

    if os.path.exists(f"{output_folder}_intrinsics.npz"):
        print(
            f"Intrinsics files for camera {cam_number} already exist. Skipping calibration."
        )
        continue

    frame_extraction(video_path, output_folder, FPS)

    # prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
    objp = np.zeros((np.prod(GRID_SHAPE), 3), np.float32)
    objp[:, :2] = (
        np.mgrid[0 : GRID_SHAPE[0], 0 : GRID_SHAPE[1]].T.reshape(-1, 2) * CELL_SIZE
    )

    # Arrays to store object points and image points from all the images.
    objpoints = []  # 3d point in real world space
    imgpoints = []  # 2d points in image plane.
    rvecs_list = []  # Rotation vectors
    tvecs_list = []  # Translation vectors

    # train path
    train_images = glob.glob(f"{output_folder}/*.png")
    cont = 0

    for fname in train_images:
        img = cv.imread(fname)
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        # Find the chess board corners automatically
        ret, corners = cv.findChessboardCorners(gray, GRID_SHAPE, None)
        # check the quaity of the image
        # the check is made only in the case of automatic detection because in the manual case it is supposed that the user ensures the accuracy beforehand
        if ret and checkQuality(gray, corners, 10, 5, 400):
            continue

        # If not found: manual detection and add object points and image points
        if ret == True:
            objpoints.append(objp)
            corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            imgpoints.append(corners2)

            # Draw and display the corners
            cv.drawChessboardCorners(img, GRID_SHAPE, corners2, ret)
            cv.waitKey(0)
            cont += 1

    cv.destroyAllWindows()

    ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(
        objpoints, imgpoints, gray.shape[::-1], None, None
    )

    # np.savez(f"{output_folder}/{cam_number}_intrinsics.npz", mtx=mtx, dist=dist)
    # np.savez(f"{output_folder}/{cam_number}_extrinsics.npz", rvecs=rvecs, tvecs=tvecs)

    # Delete the frames
    for file_name in glob.glob(f"{output_folder}/*.png"):
        os.remove(file_name)

    # print(f"Calibration for camera {cam_number} completed successfully.")

    video_path = f"data/cam{cam_number}/checkerboard.avi"
    output_folder = f"calibration/cam{cam_number}_calibration"

    if os.path.exists(f"{output_folder}_extrinsics.npz"):
        print(
            f"Extrinsics file for camera {cam_number} already exist. Skipping calibration."
        )
        continue

    frame_extraction(video_path, output_folder, FPS)

    # prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
    objp = np.zeros((np.prod(GRID_SHAPE), 3), np.float32)
    objp[:, :2] = (
        np.mgrid[0 : GRID_SHAPE[0], 0 : GRID_SHAPE[1]].T.reshape(-1, 2) * CELL_SIZE
    )

    # Arrays to store object points and image points from all the images.
    objpoints = []  # 3d point in real world space
    imgpoints = []  # 2d points in image plane.

    # train path
    train_images = glob.glob(f"{output_folder}/*.png")
    cont = 0
    for fname in train_images:
        img = cv.imread(fname)
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        # Find the chess board corners automatically
        ret, corners = cv.findChessboardCorners(gray, GRID_SHAPE, None)
        # check the quaity of the image
        # the check is made only in the case of automatic detection because in the manual case it is supposed that the user ensures the accuracy beforehand
        if ret and checkQuality(gray, corners, 10, 5, 400):
            continue

        # If not found: manual detection and add object points and image points
        if ret == False:

            #corners = automatic_chessboard_detection(img, gray)
            # select manually the four corners from the the horizzontal top left corner to the bottom left clockwise
            corners = select_corners(img, 4)

            # Linearly compute the linear interpolations from the selected corners taking into accaunt the prespective
            corners2 = linear_interpolation(corners, GRID_SHAPE[1], GRID_SHAPE[0])
            corners2 = cv.cornerSubPix(gray, corners2, (11, 11), (-1, -1), criteria)
            imgpoints.append(corners2)
            objpoints.append(objp)

        # If found: refine the points then add object points and image points
        else:
            objpoints.append(objp)
            corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            imgpoints.append(corners2)

        # Draw and display the corners
        cv.drawChessboardCorners(img, GRID_SHAPE, corners2, ret)
        cv.waitKey(0)
        if ret == False:
            cv.imshow("img", img)
            cv.waitKey(0)

    cv.destroyAllWindows()

    objpoints = np.array(objpoints, dtype=np.float32)
    imgpoints = np.array(imgpoints, dtype=np.float32)

    objpoints = objpoints.reshape(-1, 3)
    imgpoints = imgpoints.reshape(-1, 2)

    ret, rvecs, tvecs = cv.solvePnP(objpoints, imgpoints, mtx, dist)

    # np.savez(f"{output_folder}/{cam_number}_extrinsics.npz", rvecs=rvecs, tvecs=tvecs)

    # Delete the frames
    for file_name in glob.glob(f"{output_folder}/*.png"):
        os.remove(file_name)

    fs = cv.FileStorage(
        f"data/cam{cam_number}/config.xml", cv.FileStorage_WRITE
    )
    fs.write("camera_matrix", mtx)
    fs.write("dist_coeffs", dist)
    fs.write("rotation_vector", rvecs)
    fs.write("translation_vector", tvecs)
    fs.release()

    print(f"Calibration for camera {cam_number} completed successfully.")
