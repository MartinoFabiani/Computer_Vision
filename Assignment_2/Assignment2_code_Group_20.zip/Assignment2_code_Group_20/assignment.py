import glm
import random
import numpy as np
import cv2 as cv
import tqdm
from tqdm import tqdm
import matplotlib.pyplot as plt 
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from skimage import measure
import json

block_size = 1.0
resolution = 115

def generate_grid(width, depth):
    # Generates the floor grid locations
    # You don't need to edit this function
    data, colors = [], []
    for x in range(width):
        for z in range(depth):
            data.append([x*block_size - width/2, -block_size, z*block_size - depth/2])
            colors.append([1.0, 1.0, 1.0] if (x+z) % 2 == 0 else [0, 0, 0])
    return data, colors


def set_voxel_positions(width, height, depth):
    # Generates voxel locations based on their presence in the view of the 4 cameras
    data, colors = [], []
    data_mesh = np.zeros([width, height, depth], dtype=bool)
    for x in range(width):
        for y in range(height):
            for z in range(depth):
                # we multiply by 40 to increase visualization
                data.append([(x*block_size - width/2)*40 , (y*block_size - height/2)*40, (z*block_size - depth/2)*40])
                colors.append([x / width, z / depth, y / height])
    
    lookup_table = np.ones((len(data)),dtype=bool)
    for c in tqdm(range(1,5)):
        foreground_path = (
        f"voxel_reconstruction/cam{c}_foreground_mask.jpeg"
        )
        foreground = cv.imread(foreground_path, cv.IMREAD_GRAYSCALE)
        foreground[foreground < 20] = 0  
        foreground[foreground > 20] = 255
        fs = cv.FileStorage(
            f"data/cam{c}/config.xml",
            cv.FILE_STORAGE_READ,
        )
        mtx = fs.getNode("camera_matrix").mat()
        dist = fs.getNode("dist_coeffs").mat()
        dist = cv.transpose(dist)
        rvec = fs.getNode("rotation_vector").mat()
        tvec = fs.getNode("translation_vector").mat()
#
        final_data, final_colors = [], []
        # Obtain the 2D position on each camera
        pixel_pts, _ = cv.projectPoints(np.float32(data), rvec, tvec, mtx, dist)
        pixel_pts = np.squeeze(np.int32(pixel_pts))
#
        test_image = np.zeros(foreground.shape)
#
        for i, pixel in enumerate(pixel_pts):
            x_projected,y_projected = pixel
            if 0 <= y_projected < foreground.shape[1] and 0 <= x_projected < foreground.shape[0]: 
                test_image[x_projected,y_projected] = foreground[x_projected][y_projected]
                if foreground[x_projected][y_projected] != 255:
                    lookup_table[i] = False

    lookup_table = lookup_table.reshape((width, height, depth))

    for x in range(width):
        for y in range(height):
            for z in range(depth):
                if lookup_table[x][y][z] == True:
                    final_data.append([(x*block_size - width/2)-20, -(y*block_size - height/2)+70, (z*block_size - depth/2)+60])
                    final_colors.append([255, 255, 255])

                    # This is the data list type used for the mesh
                    data_mesh[x, y, z] = True
                    
    save_path = "Surface_Mesh"
    surface_mesh(data_mesh, save_path)
    print("Mesh completed successfully")
    return final_data, final_colors
def get_cam_positions():
    # Generates dummy camera locations at the 4 corners of the room
    # TODO: You need to input the estimated locations of the 4 cameras in the world coordinates.

    cameraposition = np.zeros((4, 3, 1))
    for c in range(0, 4):
        fs = cv.FileStorage(
            f"data/cam{c+1}/config.xml",
            cv.FILE_STORAGE_READ,
        )
        rvec = fs.getNode("rotation_vector").mat()
        tvec = fs.getNode("translation_vector").mat()
        rmtx = cv.Rodrigues(rvec)[0]
        cameraposition[c] = -np.dot(np.transpose(rmtx), tvec / 115)

    cameraposition2 = [
        [cameraposition[0][0][0], -cameraposition[0][2][0], cameraposition[0][1][0]*2],
        [cameraposition[1][0][0], -cameraposition[1][2][0], cameraposition[1][1][0]*2],
        [cameraposition[2][0][0]*3, -cameraposition[2][2][0], cameraposition[2][1][0]],
        [cameraposition[3][0][0], -cameraposition[3][2][0], cameraposition[3][1][0]*4],
    ]

    # Different colors are assigned to each of the cameras
    colors = [[1.0, 0, 0], [0, 1.0, 0], [0, 0, 1.0], [1.0, 1.0, 0]]
    return cameraposition2, colors
def get_cam_rotation_matrices():
    # Generates dummy camera rotation matrices, looking down 45 degrees towards the center of the room
    # TODO: You need to input the estimated camera rotation matrices (4x4) of the 4 cameras in the world coordinates.
    cam_rotations = []

    for c in range(0, 4):
        fs = cv.FileStorage(
            f"data/cam{c+1}/config.xml",
            cv.FILE_STORAGE_READ,
        )
        rvec = fs.getNode("rotation_vector").mat()
        tvec = fs.getNode("translation_vector").mat()

        rmtx = cv.Rodrigues(rvec)[0]

        matrix = glm.mat4(
            [
                [rmtx[0][0], rmtx[0][2], rmtx[0][1], tvec[0][0]],
                [rmtx[1][0], rmtx[1][2], rmtx[1][1], tvec[1][0]],
                [rmtx[2][0], rmtx[2][2], rmtx[2][1], tvec[2][0]],
                [0, 0, 0, 1],
            ]
        )

        # Considering that the camera rotation matrices are rotated with glm.
        glm_mat = glm.rotate(matrix, glm.radians(-90), (0, 1, 0))
        glm_mat = glm.rotate(glm_mat, glm.radians(180), (1, 0, 0))

        cam_rotations.append(glm_mat)

    return cam_rotations

def surface_mesh(voxels, save_path):
    with open("Computer-Vision-3D-Reconstruction/config.json", "r") as config_file:
        config = json.load(config_file)

    world_width = config["world_width"]
    world_depth = config["world_depth"]
    world_height = config["world_height"]

    verts, faces, _, _ = measure.marching_cubes(voxels)

    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection="3d")

    mesh = Poly3DCollection(verts[faces])
    mesh.set_edgecolor("k")
    ax.add_collection3d(mesh)

    # Imposta le etichette degli assi e i limiti
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.set_xlim((-world_width + 100) / 2, (world_width + 100) / 2)
    ax.set_ylim((-world_height + 100) / 2, (world_height + 100) / 2)
    ax.set_zlim(0, world_depth)
    ax.view_init(elev=10, azim=180)
    plt.tight_layout()
    plt.savefig(save_path)
