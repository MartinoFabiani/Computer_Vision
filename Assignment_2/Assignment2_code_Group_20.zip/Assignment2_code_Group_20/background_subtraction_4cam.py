# Libraries
import os

import cv2 as cv
import numpy as np
from utilities import frame_extraction

# CONSTANTS
FPS_1 = 10
FPS_2 = 1
N_CAM = 4


for cam_number in range(1, N_CAM + 1):
    background_path = f"data/cam{cam_number}/background.avi"
    video_path = f"data/cam{cam_number}/checkerboard.avi"
    output_folder = "frames"

    frame_extraction(background_path, output_folder, FPS_1)

    background_model = None
    alpha = 0.01  # Update factor of the average

    for filename in sorted(os.listdir(output_folder)):
        frame_path = os.path.join(output_folder, filename)
        frame = cv.imread(frame_path)

        if background_model is None:
            # Initiate the background model with the first frame
            background_model = frame.astype(np.float32)
        else:
            # Update the background model  with the new frame
            cv.accumulateWeighted(frame, background_model, alpha)

    background = cv.convertScaleAbs(background_model)
    hsv_background = cv.cvtColor(background, cv.COLOR_BGR2HSV)
    cv.imshow("Background Model", background)
    cv.waitKey(0)
    cv.destroyAllWindows()

    #   Delete all the frame extracted
    for filename in os.listdir(output_folder):
        file_path = os.path.join(output_folder, filename)
        os.remove(file_path)

    frame_extraction(video_path, output_folder, FPS_2)

    for filename in sorted(os.listdir(output_folder)):
        frame_path = os.path.join(output_folder, filename)
        frame = cv.imread(frame_path)

        hsv_frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
        # Compute the difference between the frame and the background
        frame_diff = cv.absdiff(hsv_frame, hsv_background)

        # Compute the histogram of hsv frame values
        hist_hue = cv.calcHist([frame_diff], [0], None, [256], [0, 256])
        hist_sat = cv.calcHist([frame_diff], [1], None, [256], [0, 256])
        hist_val = cv.calcHist([frame_diff], [2], None, [256], [0, 256])

        # Automatically define the treshold using the histogram method
        _, thresh_hue = cv.threshold(
            frame_diff[:, :, 0], 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU
        )
        _, thresh_sat = cv.threshold(
            frame_diff[:, :, 1], 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU
        )
        _, thresh_val = cv.threshold(
            frame_diff[:, :, 2], 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU
        )

        # Combine the tresholdes
        foreground_mask = cv.bitwise_or(
            cv.bitwise_or(thresh_hue, thresh_sat), thresh_val
        )

        # Find contours
        contours, _ = cv.findContours(
            foreground_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE
        )

        contour_mask = np.zeros_like(foreground_mask)

        # Find the contour with the maximum area
        max_contour = max(contours, key=cv.contourArea)

        cv.drawContours(contour_mask, [max_contour], 0, 255, -1)

        """    
        # Bob detection of contours and use them to find the main object in the frame filtering for area of contour
        for contour in contours:
            area = cv.contourArea(contour)
            if area > 200: in case of more subjects in the future this could be handy
                # cv.drawContours(frame, [contour], -1, (0, 255, 0), 1)
                cv.drawContours(
                    contour_mask, [contour], 0, 255, -1
                )  # Fill  inside contour with white pixel
        """

        # Bob detection: detect contours with cv.findcontours from an image.
        # Find the maximum contour (main subject) and draw around.

        # Instead of contour, create mask: black image with filled white contour.
        # Use cv.bitwise_and to apply AND between two images.

        # Remain in foreground_mask only what's inside the detected contour.
        # Result is the main object retained in the final image.

        # Apply the mask at the foreground mask
        filtered_mask = cv.bitwise_and(foreground_mask, contour_mask)

        cv.imshow("Foreground", filtered_mask)
        cv.waitKey(0)

    cv.destroyAllWindows()

    #   Delete all the frames extracted
    for filename in os.listdir(output_folder):
        file_path = os.path.join(output_folder, filename)
        os.remove(file_path)


os.rmdir(output_folder)
