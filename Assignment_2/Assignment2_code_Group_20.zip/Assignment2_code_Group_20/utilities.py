# importing the module
import os

import cv2
import numpy as np

GRID_SHAPE = (6, 8)
magnification_factor = 10  # You can adjust this value
circle_radius = 2.5  # You can adjust this value


# function to check the quality of the given image in the offline phase and
# return an acceptance estimation based on a sharpness and brightness thresholds
def checkQuality(
    gray, corners, sharpness_limit, min_brightness_limit, max_brightness_limit
):
    quality, _ = cv2.estimateChessboardSharpness(gray, GRID_SHAPE, corners)
    avg_sharpness, avg_min_brightness, avg_max_brightness, _ = quality
    if (
        avg_sharpness > sharpness_limit
        or avg_min_brightness < min_brightness_limit
        or avg_max_brightness > max_brightness_limit
    ):
        return True


def frame_extraction(video_path, output_folder, FPS):
    # Controlla se la cartella di output esiste, altrimenti creala
    if os.path.exists(output_folder):
        if any(fname.endswith(".png") for fname in os.listdir(output_folder)):
            print(
                f"The folder '{output_folder}' already exists and it contains PNG files."
            )
            return
    else:
        os.makedirs(output_folder)

    # Apre il video
    video = cv2.VideoCapture(video_path)
    fps_video = video.get(cv2.CAP_PROP_FPS)  # Ottieni l'FPS del video
    frame_skip = int(fps_video / FPS)

    success, frame = video.read()
    count = 0

    # Estrae i frame fino alla fine del video
    while success:
        if count % frame_skip == 0:
            # Salva il frame come file PNG nella cartella di output
            cv2.imwrite(os.path.join(output_folder, f"frame_{count:04d}.png"), frame)

        # Legge il prossimo frame
        success, frame = video.read()
        count += 1

    # Chiude il video
    video.release()

def getMagnifiedImage(image, x, y, factor, radius):
    h, w = image.shape[:2]

    # Ensure the mouse coordinates are within the image boundaries
    x = max(radius, min(w - radius, x))
    y = max(radius, min(h - radius, y))

    # Define the region of interest (ROI)
    x1, y1 = int(x - radius), int(y - radius)
    x2, y2 = int(x + radius), int(y + radius)

    # Crop the region around the mouse
    roi = image[y1:y2, x1:x2]

    # Resize the cropped region to create a magnified effect
    magnified_roi = cv2.resize(roi, None, fx=factor, fy=factor, interpolation=cv2.INTER_LINEAR)

    # Ensure that the dimensions match before pasting
    image_copy = image.copy()
    new_radius = int(radius * factor)
    y1, x1 = int(y - new_radius), int(x - new_radius)
    y2, x2 = int(y + new_radius), int(x + new_radius)
    image_copy[y1:y2, x1:x2] = magnified_roi

    # Draw a marker or circle at the cursor position on the magnified view
    cv2.circle(image_copy, (x1 + new_radius, y1 + new_radius), 5, (0, 255, 0), -1)

    return image_copy

# function to display the coordinates of
# of the points clicked on the image
def click_event(event, x, y, flags, params):
    img, corners = params

    if event == cv2.EVENT_MOUSEMOVE:
        # Update the magnified view directly on the original image
        magnified_image = getMagnifiedImage(img, x, y, magnification_factor, circle_radius)
        cv2.imshow('Magnified image', magnified_image)

    # checking for left mouse clicks
    if event == cv2.EVENT_LBUTTONDOWN or event == cv2.EVENT_RBUTTONDOWN:
        # displaying the coordinates on the image window
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img, str(x) + "," + str(y), (x, y), font, 1, (255, 0, 0), 1)
        cv2.imshow("image", img)
        corners.append((x, y))

# function to store the given 4 chessboard corner coordinates from the click inputs
def select_corners(img, num_corners=4):
    corners = []

    cv2.imshow("image", img)

    cv2.setMouseCallback("image", click_event, (img, corners))
    key = cv2.waitKey(0)

    cv2.destroyAllWindows()

    if len(corners) != num_corners:
        raise ValueError(f"You must select exactly {num_corners} points on the image")

    corners_array = np.array(corners, dtype=np.float32)
    return corners_array

# finds the 4 chesboard corners automatically
def automatic_chessboard_detection(image, gray):
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply GaussianBlur to reduce noise and improve Hough line detection
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny edge detection
    edges = cv2.Canny(blurred, 50, 150)

    # Use HoughLinesP to detect lines in the image
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=100, maxLineGap=10)

    # Draw the detected lines on a copy of the original image
    line_image = np.copy(image)
    for line in lines:
        x1, y1, x2, y2 = line[0]
        cv2.line(line_image, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # Find contours in the line image
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Sort contours by area and find the largest one (the outer boundary)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:1]

    # Draw the largest contour on a black background
    contour_image = np.zeros_like(gray)
    cv2.drawContours(contour_image, contours, 0, (255), thickness=cv2.FILLED)

    # Find the corners of the largest contour using the approxPolyDP function
    epsilon = 0.02 * cv2.arcLength(contours[0], True)
    corners = cv2.approxPolyDP(contours[0], epsilon, True)

    # If there are exactly 4 corners, draw them on the original image
    if len(corners) == 4:
        # Assuming the order of corners is top-left, top-right, bottom-left, bottom-right
        top_left, top_right, bottom_left, bottom_right = np.squeeze(corners)

        # Draw the shifted outer corners on the original image
        cv2.circle(image, top_left, 10, (0, 0, 255), -1)
        cv2.circle(image, top_right, 10, (0, 0, 255), -1)
        cv2.circle(image, bottom_left, 10, (0, 0, 255), -1)
        cv2.circle(image, bottom_right, 10, (0, 0, 255), -1)


        # Display the result
        cv2.imshow('Chessboard Detection', image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        return np.array(corners,dtype=np.float32)

# function that applies linear interpolation using the manually annotated chessboard corners and returns
# all the corners points of the squares within the grid pattern
def linear_interpolation(corners, num_cells_column, num_cells_row):
    upper_left, upper_right, bottom_right, bottom_left = corners

    # Compute the width and the height given the corners
    diff_upper_right = np.subtract(upper_right, upper_left)
    diff_bottom_left = np.subtract(bottom_left, upper_left)

    width = np.linalg.norm(diff_upper_right)
    height = np.linalg.norm(diff_bottom_left)

    # Compute the step for both axes
    step_x = width / (num_cells_row - 1)*1
    step_y = height / (num_cells_column - 1)*1

    # Generate the cordinates of all the inner points of a non tilted chessboard by linear interpolation
    uniform_points = np.zeros(
        (num_cells_row * num_cells_column, 1, 2), dtype=np.float32
    )
    for j in range(num_cells_column):
        for i in range(num_cells_row):
            uniform_points[j * num_cells_row + i, 0, 0] = i * step_x
            uniform_points[j * num_cells_row + i, 0, 1] = j * step_y

    # Generate the untilted 2D rectangle with dimensions derived from the differences of the four corners inserted manually
    orig_points = np.array(
        [[0, 0], [width, 0], [width, height], [0, height]], dtype=np.float32
    )
    # Finds the perspective matrix that takes the orig_points and obtain the corners provided
    transform_mat = cv2.getPerspectiveTransform(orig_points, corners)
    print(transform_mat)
    # Apply the transformation to all the uniform point (all the inner points)
    inner_square_coordinates = cv2.perspectiveTransform(uniform_points, transform_mat)

    return inner_square_coordinates.reshape(-1, 2)


# function that sharpens the images and helps increase the number of pictures for which
# cv2.findChessboardCorners() can find the corners automatically
def sharpen_image(image):
    kernel = np.array([[0, -1, 0],
                   [-1, 5,-1],
                   [0, -1, 0]])
    image_sharp = cv2.filter2D(src=image, ddepth=-1, kernel=kernel)

    return image_sharp

# function to draw the XYZ world axes onto the given chessboard image
def draw_world_axes(img, corners, imgpts):
    corner = tuple(corners[0].ravel().astype(int))
    img = cv2.line(img, corner, tuple(imgpts[0].ravel().astype(int)), (255, 0, 0), 2)
    img = cv2.line(img, corner, tuple(imgpts[1].ravel().astype(int)), (0, 255, 0), 2)
    img = cv2.line(img, corner, tuple(imgpts[2].ravel().astype(int)), (0, 0, 255), 2)
    return img

# function to draw the NxNxN cube onto the given chessboard image
def draw_cube(img, corners, imgpts):
    imgpts = np.int32(imgpts).reshape(-1, 2)
    # draw ground floor in green
    img = cv2.drawContours(img, [imgpts[:4]], -1, (0, 255, 255), 2)
    # draw pillars in blue color
    for i, j in zip(range(4), range(4, 8)):
        img = cv2.line(img, tuple(imgpts[i]), tuple(imgpts[j]), (0,255,255), 2)
    # draw top layer in red color
    img = cv2.drawContours(img, [imgpts[4:]], -1, (0, 255, 255), 2)
    return img

# function to be used in the online phase that finds the chessboard corners automatically and projects
# the wanted shapes onto an image using the calibrated camera intrinstic parameters and distortion coefficients matrices
def draw(img, criteria, objp, mtx, dist, rvec, tvec, axis, cube_axis):
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    ret, corners = cv2.findChessboardCorners(gray, GRID_SHAPE,None)
    if ret == True:
        cv2.drawChessboardCorners(img, GRID_SHAPE, corners, ret)
        cv2.imshow('image',img)
        cv2.waitKey(0)
        corners2 = cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
        # Find the rotation and translation vectors.
        #print(objp, objp.shape)
        #print(corners2, corners2.shape)
        ret,rvec, tvec = cv2.solvePnP(objp, corners2, mtx, dist)
        print(rvec, tvec)
        # project 3D points to image plane
        imgpts, jac = cv2.projectPoints(axis, rvec, tvec, mtx, dist)
        #cubeimgpts, jac = cv2.projectPoints(cube_axis, rvec, tvec, mtx, dist)
        img = draw_world_axes(img,corners2,imgpts)
        #img = draw_cube(img, corners2, cubeimgpts)

        return img
    else:
        corners = select_corners(img, 4)
        # Linearly compute the linear interpolations from the selected corners taking into accaunt the prespective
        corners2 = linear_interpolation(corners, GRID_SHAPE[1], GRID_SHAPE[0])
        corners2 = cv2.cornerSubPix(gray,corners2,(11,11),(-1,-1),criteria)
        cv2.drawChessboardCorners(img, GRID_SHAPE, corners2, ret)
        cv2.imshow('image',img)
        cv2.waitKey(0)
        # Find the rotation and translation vectors.
        #print(objp, objp.shape)
        #print(corners2, corners2.shape)
        ret,rvec, tvec = cv2.solvePnP(objp, corners2, mtx, dist)
        print(rvec, tvec)
        # project 3D points to image plane
        imgpts, jac = cv2.projectPoints(axis, rvec, tvec, mtx, dist)
        #cubeimgpts, jac = cv2.projectPoints(cube_axis, rvecs, tvecs, mtx, dist)
        img = draw_world_axes(img,corners2,imgpts)
        #img = draw_cube(img, corners2, cubeimgpts)
        return img