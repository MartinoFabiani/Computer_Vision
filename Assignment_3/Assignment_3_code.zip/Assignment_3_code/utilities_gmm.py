import os

import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize
from tqdm import tqdm

predefined_colors = [
    [255, 0, 0],  # Red
    [0, 255, 0],  # Green
    [0, 0, 255],  # Blue
    [255, 255, 0],  # Yellow
]

center_values = []
color_values = []

def clustering(voxels):

    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 10, 0.1)

    voxels = np.float32(voxels)[:, [0, 2]]
    _, labels, centers = cv.kmeans(
        voxels, 4, None, criteria, 20, cv.KMEANS_RANDOM_CENTERS
    )

    return labels, centers

# creates color model using GMM in HSV color space
def create_color_model(voxels, lookuptable):
    labels, centers = clustering(voxels)
    voxels, labels, centers = remove_outliers(voxels, labels, centers, 8)

    labels = np.ravel(labels)
    voxels = np.float32(voxels)

    cam_color_models = [[], [], [], []]

    for i in tqdm(range(4), desc="Creating color models"):
        color_model_cam = []
        frame = cv.imread(f"frame{i+1}.jpeg")
        frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)

        for label in range(4):
            voxels_person = voxels[labels == label]
            pixel_cluster, color_cluster = [], []

            tshirt = np.mean(voxels_person[:, 1], dtype=np.int_)
            voxel_roi = voxels_person[:, 1] > tshirt
            voxels_person_roi = voxels_person[voxel_roi]

            head = np.max(voxels_person_roi[:, 1])
            voxel_roi = voxels_person_roi[:, 1] < 3 / 4 * head
            voxels_person_roi = voxels_person_roi[voxel_roi]

            for v in voxels_person_roi:
                pixel = lookuptable[i][tuple(v)]
                pixel_cluster.append(pixel)

            color_cluster = np.array([frame[y, x] for x, y in pixel_cluster])

            model = cv.ml.EM_create()
            model.setClustersNumber(3)

            model.trainEM(np.float32(color_cluster))

            color_model_cam.append(model)

        cam_color_models[i] = color_model_cam

    return cam_color_models


def online_4cams(color_models, voxel_list, lookup_table_cams, frames, frame_cnt, img_floor):

    # Performs the online phase with 4 cameras

    labels, centers = clustering(voxel_list)
    voxels, labels, centers = remove_outliers(voxel_list, labels, centers, 8)

    labels = np.ravel(labels)
    voxels = np.float32(voxels)

    print(f"Online Phase - Current time: {frame_cnt}")

    cam_labels = []

    for i in tqdm(range(4), desc="Online Phase"):
        colors = []
        final_voxels = []
        matching = []
        frame = frames[i]
        frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)

        for label in range(4):
            voxels_person = voxels[labels == label]
            pixel_cluster = []

            final_voxels.append(voxels_person)

            tshirt = np.mean(voxels_person[:, 1], dtype=np.int_)
            voxel_roi = voxels_person[:, 1] > tshirt
            voxels_person_roi = voxels_person[voxel_roi]

            head = np.max(voxels_person_roi[:, 1])
            voxel_roi = voxels_person_roi[:, 1] < 3 / 4 * head
            voxels_person_roi = voxels_person_roi[voxel_roi]

            for v in voxels_person_roi:
                pixel = lookup_table_cams[i][tuple(v)]
                pixel_cluster.append(pixel)

            pred_values = []

            for j in range(len(color_models[i])):
                colors_cluster = np.array(
                    [frame[y, x] for x, y in pixel_cluster], dtype=np.float32
                )

                overall_logprob = 0.0
                for sample in colors_cluster:
                    (logprob, _), _ = color_models[i][j].predict2(sample)
                    overall_logprob += logprob

                pred_values.append(overall_logprob)

            matching.append(pred_values)

        new_labels = optimize.linear_sum_assignment(np.array(matching))
        cam_labels.append(tuple(new_labels[1].tolist()))

    final_labels = assign_final_labels(cam_labels)

    colors = []


    centers_color = []
    people_centers = []

    for j in range(len(final_labels)):
        color = assign_color(final_voxels[j], final_labels[j])
        colors.append(color)
        centers_color.append(color[0])
        people_centers.append(centers[j].tolist())


    global center_values, color_values
    center_values.append(people_centers)
    color_values.append(centers_color)
    final_voxels = np.concatenate(final_voxels).tolist()
    final_colors = np.concatenate(colors).tolist()

    draw_floor(center_values, color_values, img_floor)

    return final_voxels, final_colors

# draws the trajectories on a the floor image
def draw_floor(positions, colors, img_floor):
    for v in range(len(positions)):
        prev_x, prev_y = None, None
        for i in range(len(positions[v])):
            x, y = positions[v][i]
            x = int((x + 100) / 200.0 * 500.0)
            y = int((y + 100) / 200.0 * 500.0)
            r, g, b = colors[v][i]
            color = (int(b), int(g), int(r))

            if prev_x is not None and prev_y is not None and color == prev_color:
                cv.line(img_floor, (prev_x, prev_y), (x, y), color, 2)

            cv.circle(img_floor, (x, y), 5, color, -1)

            prev_x, prev_y = x, y
            prev_color = color


    filename = f"trajectory/Captured_image_{len(positions)}.png"
    cv.imwrite(filename, img_floor)
    print("Image saved as:", filename)

def online(
    color_models, voxel_list, lookup_table_cams, frames, frame_cnt, camera_index, img_floor
):
    # Performs the online phase only with one camera

    labels, centers = clustering(voxel_list)
    voxels, labels, centers = remove_outliers(voxel_list, labels, centers, 8)

    labels = np.ravel(labels)
    voxels = np.float32(voxels)

    print(f"Online Phase - Current time: {frame_cnt}")

    i = camera_index

    final_labels = []
    colors = []
    final_voxels = []

    frame = frames[i]
    frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    for label in range(4):
        voxels_person = voxels[labels == label]
        pixel_cluster = []

        final_voxels.append(voxels_person)

        tshirt = np.mean(voxels_person[:, 1], dtype=np.int_)
        voxel_roi = voxels_person[:, 1] > tshirt
        voxels_person_roi = voxels_person[voxel_roi]

        head = np.max(voxels_person_roi[:, 1])
        voxel_roi = voxels_person_roi[:, 1] < 3 / 4 * head
        voxels_person_roi = voxels_person_roi[voxel_roi]

        for v in voxels_person_roi:
            pixel = lookup_table_cams[i][tuple(v)]
            pixel_cluster.append(pixel)

        pred_values = []

        for j in range(len(color_models[i])):
            colors_cluster = np.array(
                [frame[y, x] for x, y in pixel_cluster], dtype=np.float32
            )

            overall_logprob = 0.0
            for sample in colors_cluster:
                (logprob, _), _ = color_models[i][j].predict2(sample)
                overall_logprob += logprob

            pred_values.append(overall_logprob)

        max_logprob_index = np.argmax(pred_values)
        final_labels.append(max_logprob_index)

    centers_color = []
    people_centers = []
    for j in range(len(final_labels)):
        color = assign_color(final_voxels[j], final_labels[j])
        colors.append(color)
        centers_color.append(color[0])
        people_centers.append(centers[j].tolist())

    global center_values, color_values
    center_values.append(people_centers)
    color_values.append(centers_color)
    final_voxels = np.concatenate(final_voxels).tolist()
    final_colors = np.concatenate(colors).tolist()

    draw_floor(center_values, color_values, img_floor)

    return final_voxels, final_colors

# removes outliers by setting a throushold on the distance from the cluster center
def remove_outliers(voxels, labels, centers, threshold):
    clean_voxels = []
    clean_labels = []

    for i, voxel in enumerate(voxels):
        label = labels[i]
        center = centers[label]
        x = voxel[0]
        z = voxel[2]
        pixel = (x, z)

        # Compute the distance betwen the center and the pixel
        distance = np.linalg.norm(pixel - center)

        # Verify if the voxel is an outlier or a ghost voxel
        if distance < threshold:
            clean_voxels.append(voxel)
            clean_labels.append(label)

    cluster_voxels = np.float32(clean_voxels)[:, [0, 2]]

    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 10, 0.1)

    _, clean_labels, clean_centers = cv.kmeans(
        cluster_voxels, 4, None, criteria, 20, cv.KMEANS_RANDOM_CENTERS
    )

    return clean_voxels, clean_labels, clean_centers

# assign colors to voxels using the label
def assign_color(voxels, label):
    return [predefined_colors[label] for _ in range(np.shape(voxels)[0])]

# makes decision on the final label
def assign_final_labels(cam_labels):
    seen = {}
    for lst in cam_labels:
        key = tuple(lst)
        if key in seen:
            seen[key] += 1
            if seen[key] == 2:
                del seen[key]
        else:
            seen[key] = 1
    for lst in cam_labels:
        if lst == cam_labels[2]:
            return lst
    for lst in cam_labels:
        if tuple(lst) in seen:
            return lst
