import os
import random

import cv2 as cv
import glm
import numpy as np
from tqdm import tqdm

from utilities_gmm import create_color_model, online, online_4cams

# global variables
block_size = 1.0
voxel_size = 30.0  # voxel every 3cm
frame_represented = 6
lookup_table = []
camera_handles = []
background_models = []
offline = True
colors_model = None


# generate the floor grid locations
def generate_grid(width, depth):
    data, colors = [], []
    for x in range(width):
        for z in range(depth):
            data.append(
                [x * block_size - width / 2, -block_size, z * block_size - depth / 2]
            )
            colors.append([1.0, 1.0, 1.0] if (x + z) % 2 == 0 else [0, 0, 0])
    return data, colors


# determines which voxels should be set
def set_voxel_positions(width, height, depth, curr_time, frame_cnt):
    global offline, color_models, img_floor
    if len(lookup_table) == 0:
        create_lookup_table(width, height, depth)
        img_floor = np.ones((500, 500, 3), dtype=np.uint8) * 255
    # initialize voxel list
    voxel_list = []

    # swap y and z
    voxel_grid = np.ones((width, depth, height), np.float32)

    foreground_masks, frames = background_subtraction(frame_cnt)

    for i_camera in tqdm(range(4), desc="Voxel Reconstruction"):

        foreground_mask = foreground_masks[i_camera]

        # set voxel to off if it is not visible in the camera, or is not in the foreground
        for x in range(width):
            for y in range(height):
                for z in range(depth):
                    if not voxel_grid[x, z, y]:
                        continue
                    voxel_index = z + y * depth + x * (depth * height)

                    if not np.isinf(lookup_table[i_camera][voxel_index][0][0]):
                        projection_x = int(lookup_table[i_camera][voxel_index][0][0])
                    else:
                        projection_x = 1e6

                    if not np.isinf(lookup_table[i_camera][voxel_index][0][1]):
                        projection_y = int(lookup_table[i_camera][voxel_index][0][1])
                    else:
                        projection_y = 1e6
                    if (
                        projection_x < 0
                        or projection_y < 0
                        or projection_x >= foreground_mask.shape[1]
                        or projection_y >= foreground_mask.shape[0]
                        or not foreground_mask[projection_y, projection_x]
                    ):
                        voxel_grid[x, z, y] = 0.0
    colors = []
    lookup_table_cams = [
        {},
        {},
        {},
        {},
    ]
    voxel_list = []

    for x in range(width):
        for y in range(height):
            for z in range(depth):
                if voxel_grid[x, z, y] > 0:
                    v = [
                        x * block_size - width / 2,
                        y * block_size,
                        z * block_size - depth / 2,
                    ]
                    voxel_list.append(v)
                    voxel_index = z + y * depth + x * (depth * height)

                    for i in range(4):
                        projection_x, projection_y = map(
                            int, lookup_table[i][voxel_index][0]
                        )
                        lookup_table_cams[i][tuple(v)] = [projection_x, projection_y]
                    colors.append([x / width, z / depth, y / height])

    print(f"OFFLINE = {offline}")
    if offline:
        color_models = create_color_model(voxel_list, lookup_table_cams)
        offline = False

    final_voxels, final_colors = online(
        color_models, voxel_list, lookup_table_cams, frames, frame_cnt, 1, img_floor
    )
    print("Reconstruction Completed Successfully")

    return final_voxels, final_colors


# create lookup table
def create_lookup_table(width, height, depth):
    global offline
    # create 3d voxel grid
    voxel_space_3d = []
    for x in tqdm(range(width), desc="Lookup Table Construction"):
        for y in range(height):
            for z in range(depth):
                voxel_space_3d.append(
                    [
                        voxel_size * (x * block_size - width / 2),
                        voxel_size * (z * block_size - depth / 2),
                        -voxel_size * (y * block_size),
                    ]
                )

    for i_camera in range(4):
        camera_path = "./data/cam" + str(i_camera + 1)

        # use config.xml to read camera calibration
        file_handle = cv.FileStorage(camera_path + "/config.xml", cv.FileStorage_READ)
        mtx = file_handle.getNode("CameraMatrix").mat()
        dist = file_handle.getNode("DistortionCoeffs").mat()
        rvec = file_handle.getNode("Rotation").mat()
        tvec = file_handle.getNode("Translation").mat()
        file_handle.release()

        # project voxel 3d points to 2d in each camera
        voxel_space_2d, jac = cv.projectPoints(
            np.array(voxel_space_3d, np.float32), rvec, tvec, mtx, dist
        )
        lookup_table.append(voxel_space_2d)


def background_subtraction(frame_cnt):
    N_CAM = 4
    foreground_masks = []
    color_masks = []

    for cam in tqdm(range(N_CAM), desc="Background Subtractions"):
        # Carica il video per lo sviluppo del background
        background_video_path = f"data/cam{cam+1}/background.avi"
        background_video = cv.VideoCapture(background_video_path)

        # Inizializza il modello MOG2 per la sottrazione del background
        background_model = cv.createBackgroundSubtractorMOG2()

        # Processa il video per lo sviluppo del background
        while True:
            ret, background_frame = background_video.read()
            if not ret:
                break
            background_model.apply(background_frame)
        background_video.release()

        # Carica il video per la sottrazione del background
        motion_video_path = f"data/cam{cam+1}/video.avi"
        motion_video = cv.VideoCapture(motion_video_path)

        motion_video.set(cv.CAP_PROP_POS_FRAMES, frame_cnt)

        ret, frame = motion_video.read()

        # Applica la sottrazione del background utilizzando MOG2
        foreground_image = background_model.apply(frame, learningRate=0)
        _, thresholded = cv.threshold(foreground_image, 240, 255, cv.THRESH_BINARY)

        # Esegui operazioni morfologiche per pulire il rumore
        kernel = cv.getStructuringElement(cv.MORPH_ELLIPSE, (3, 3))
        mask = cv.dilate(thresholded, kernel)
        mask = cv.erode(mask, kernel)

        contours, _ = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        contour_mask = np.zeros_like(mask)

        for contour in contours:
            area = cv.contourArea(contour)
            if area > 4000:
                cv.drawContours(contour_mask, [contour], 0, 255, -1)

        filtered_mask = cv.bitwise_and(mask, contour_mask)

        foreground_masks.append(filtered_mask)
        color_masks.append(frame)

        # cv.imshow(f"Filtered Mask - Camera {cam+1}", filtered_mask)
        # cv.imshow(f"Frame - Camera {cam+1}", frame)
        # cv.waitKey(0)
        # cv.destroyAllWindows()

        motion_video.release()
        cv.destroyAllWindows()

    return foreground_masks, color_masks


# Gets stored camera positions
def get_cam_positions():
    cam_positions = []

    for i_camera in range(4):
        camera_path = "./data/cam" + str(i_camera + 1)
        file_handle = cv.FileStorage(camera_path + "/config.xml", cv.FileStorage_READ)
        tvec = file_handle.getNode("Translation").mat()
        rvec = file_handle.getNode("Rotation").mat()
        file_handle.release()
        # obtain positions
        rotation_matrix = cv.Rodrigues(rvec)[0]
        positions = -np.matrix(rotation_matrix).T * np.matrix(tvec / voxel_size)
        cam_positions.append([positions[0][0], -positions[2][0], positions[1][0]])
    return cam_positions, [[1.0, 0, 0], [0, 1.0, 0], [0, 0, 1.0], [1.0, 1.0, 0]]


# Gets stored camera rotations
def get_cam_rotation_matrices():
    cam_rotations = []

    for i in range(4):
        camera_path = "./data/cam" + str(i + 1)
        file_handle = cv.FileStorage(camera_path + "/config.xml", cv.FileStorage_READ)
        rvec = file_handle.getNode("Rotation").mat()
        file_handle.release()

        # # normalize rotations
        angle = np.linalg.norm(rvec)
        axis = rvec / angle

        # apply rotation to compensate for difference between OpenCV and OpenGL
        transform = glm.rotate(-0.5 * np.pi, [0, 0, 1]) * glm.rotate(
            -angle, glm.vec3(axis[0][0], axis[1][0], axis[2][0])
        )
        transform_to = glm.rotate(0.5 * np.pi, [1, 0, 0])
        transform_from = glm.rotate(-0.5 * np.pi, [1, 0, 0])
        cam_rotations.append(transform_to * transform * transform_from)
    return cam_rotations
