import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import cv2 as cv
from pytorch_grad_cam import GradCAM
from TwoStream_model import TwoStreamNetwork, OpticalFlowNet

# load trained models
frame_model = torch.hub.load("pytorch/vision:v0.10.0", "googlenet", pretrained=True)
num_ftrs = frame_model.fc.in_features
frame_model.fc = torch.nn.Sequential(
    torch.nn.Linear(num_ftrs, 12),
    torch.nn.Softmax(dim=1),
)
frame_model.load_state_dict(torch.load('Models/GoogleNet_HDMB51_weights.pth'))
#frame_model = torch.nn.Sequential(*list(frame_model.children())[:-3])
#frame_model.add_module(
#    "additional_conv", torch.nn.Conv2d(1024, 128, kernel_size=1, stride=1, padding=0)
#)
#
#optical_flow_model = OpticalFlowNet(12,8)
#optical_flow_model.load_state_dict(torch.load("Models/HDMB510_opticalflow_weights.pth"),strict=False)
#
#model = TwoStreamNetwork(frame_model, optical_flow_model, 12)
#model.load_state_dict(torch.load('Models/TwoStream_weights.pth'))

target_layer = [frame_model.inception5b.branch4[1].conv]
# Initialize the GradCAM
cam = GradCAM(model=frame_model, target_layers=target_layer)  # Specify the target_layer instead

# Define the preprocessing transform
preprocess = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

def extract_middle_frame(video_path):
    # Open the video file
    cap = cv.VideoCapture(video_path)
    
    # Get the total number of frames
    total_frames = int(cap.get(cv.CAP_PROP_FRAME_COUNT))
    # Calculate the middle frame index
    middle_frame_index = total_frames // 2
    
    # Set the frame index to the middle frame
    cap.set(cv.CAP_PROP_POS_FRAMES, middle_frame_index)
    
    # Read the middle frame
    ret, frame = cap.read()
    
    # Release the video capture object
    cap.release()
    
    return frame

def extract_optical_flow(video_path, stack_size):
    cap = cv.VideoCapture(video_path)
    ret, prev_frame = cap.read()
    prev_frame = cv.resize(prev_frame, (224, 224))
    prev_gray = cv.cvtColor(prev_frame, cv.COLOR_BGR2GRAY)
    flows = []
    stack_count = 0
    while True:
        ret, next_frame = cap.read()
        if not ret or stack_count == stack_size:
            break
        next_frame = cv.resize(next_frame, (224, 224))
        next_gray = cv.cvtColor(next_frame, cv.COLOR_BGR2GRAY)
        flow = cv.calcOpticalFlowFarneback(
            prev_gray, next_gray, None, 0.5, 3, 15, 3, 5, 1.2, 0
        )
        flows.append(flow)
        prev_gray = next_gray
        stack_count += 1
    cap.release()
    return np.array(flows)

def plot_grad_cam(model, input_path):
    model.eval()
    # Extract middle frame
    image = extract_middle_frame(input_path)

    # Extract optical flow
    optical_flow = extract_optical_flow(input_path, 8)
    optical_flow_tensor = torch.tensor(optical_flow, dtype=torch.float32).unsqueeze(0)
    #optical_flow_tensor = optical_flow_tensor.permute(0, 4, 1, 2, 3)
    #optical_flow_tensor = optical_flow_tensor.reshape((optical_flow_tensor.size(0), 8*2, 224, 224))
    # Load and preprocess the image
    image = Image.fromarray(image)

    input_image = preprocess(image).unsqueeze(0)  # Add batch dimension

    # Concatenate image and optical flow tensors along the channel dimension
    #input_tensor = torch.cat((input_image, optical_flow_tensor), dim=1)

    cam_image = cam(input_tensor=input_image, targets=None)

    # Convert CAM to numpy array
    cam_image = np.array(cam_image.squeeze(0))

    # Rescale CAM to range [0, 255]
    cam_image = (cam_image - cam_image.min()) / (cam_image.max() - cam_image.min()) * 255
    cam_image = cam_image.astype(np.uint8)

    # Resize CAM to match the input image size
    cam_image = cv.resize(cam_image, (224,224))

    # Apply colormap (heatmap)
    heatmap = cv.applyColorMap(cam_image, cv.COLORMAP_JET)

    image = np.array(image, dtype=np.uint8)
    image = cv.resize(image,(224,224))

    # Overlay heatmap on original image
    overlaid_image = cv.addWeighted(image, 0.5, heatmap, 0.5, 0)

    cv.imwrite("Plots/HMDB51_frames_clap.png",overlaid_image)

#plot_grad_cam(model=model, input_path='video_data\climb\climb\Alban_Hayoz_solo_climb_(klettern)_climb_f_cm_np1_ba_med_0.avi')
plot_grad_cam(model=frame_model, input_path='video_data\clap\clap/103_years_old_japanese_woman__Nao_is_clapping_with_piano_music_by_beethoven_clap_u_nm_np1_fr_med_0.avi')
