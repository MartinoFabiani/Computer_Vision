from collections import Counter
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
import cv2 as cv
from PIL import Image
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os
import torch
from torchvision import datasets, transforms
import torchkeras

# STANFORD40 SPLIT

keep_stanford40 = ["applauding", "climbing", "drinking", "jumping", "pouring_liquid", "riding_a_bike", "riding_a_horse", 
        "running", "shooting_an_arrow", "smoking", "throwing_frisby", "waving_hands"]
with open('Stanford40/ImageSplits/train.txt', 'r') as f:
    # We won't use these splits but split them ourselves
    train_files = [file_name for file_name in list(map(str.strip, f.readlines())) if '_'.join(file_name.split('_')[:-1]) in keep_stanford40]
    train_labels = ['_'.join(name.split('_')[:-1]) for name in train_files]

with open('Stanford40/ImageSplits/test.txt', 'r') as f:
    # We won't use these splits but split them ourselves
    test_files = [file_name for file_name in list(map(str.strip, f.readlines())) if '_'.join(file_name.split('_')[:-1]) in keep_stanford40]
    test_labels = ['_'.join(name.split('_')[:-1]) for name in test_files]

# Combine the splits and split for keeping more images in the training set than the test set.
all_files = train_files + test_files
all_labels = train_labels + test_labels
train_files, test_files = train_test_split(all_files, test_size=0.1, random_state=0, stratify=all_labels)
train_labels = ['_'.join(name.split('_')[:-1]) for name in train_files]
test_labels = ['_'.join(name.split('_')[:-1]) for name in test_files]


action_to_index = {action: index for index, action in enumerate(keep_stanford40)}
# Define a transform to convert 
# the image to torch tensor 
preprocess = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])
# function to load images and labels in a way similar to pytorch Dataset
def load_data(data_files):
    data = []
    labels = []
    for file_name in data_files:
        action = '_'.join(file_name.split('_')[:-1])
        label = action_to_index[action]
        img = cv.imread(os.path.join("Stanford40/JPEGImages", file_name))
        img = cv.cvtColor(img, cv.COLOR_BGR2RGB)
        img = Image.fromarray(img)
        tensor = preprocess(img)
        tensor_label = (tensor, label)
        data.append(tensor_label)
        labels.append(label)
    return data, labels


dataset_train, train_labels = load_data(train_files)
dataset_test, test_labels = load_data(test_files)

dataset_train, dataset_val = train_test_split(dataset_train, test_size=0.1, random_state=0, stratify=train_labels)

# load the different datasets into dataloaders
train_dataloader = DataLoader(dataset_train, batch_size=32, shuffle=True)
val_dataloader = DataLoader(dataset_val, batch_size=32, shuffle=False)
test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)

model = torch.hub.load('pytorch/vision:v0.10.0', 'googlenet', pretrained=True)

# Modify the fully connected layer
num_ftrs = model.fc.in_features
model.fc = torch.nn.Sequential(
    torch.nn.Linear(num_ftrs, 12),
    torch.nn.Softmax(dim=1),
)
torchkeras.summary(model, input_shape=(3,224,224))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
#scheduler = torch.optim.lr_scheduler.CyclicLR(optimizer, base_lr=0.01, max_lr=0.1, step_size_up=5, step_size_down=5, mode="triangular2", cycle_momentum=False)

learning_rates = []
learning_rate = 0.001

# half the learning rate every 5 epochs for better learning
def adjust_learning_rate(optimizer, epoch, lr):
    lr = lr * (0.5 ** (epoch // 5))
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    learning_rates.append(lr)
    return lr

epochs = 25


total_accuracies = [[], []]
total_losses = [[], []]

# standard train function where the model weights get updated
def train(dataloader, model, criterion, optimizer):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)

        pred = model(x)
        loss = criterion(pred, y)

        train_loss += criterion(pred, y)
        correct += (pred.argmax(1) == y).sum().item()

        loss.backward()
        optimizer.step()
        #scheduler.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[0].append(train_loss)
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[0].append(train_accuracy)
    print(f"Train Error: \n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f} \n")

all_preds = []
all_targets = []

# standard test function which can be used for validation and testing
def test(dataloader, model, criterion, mode="Val"):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            pred = model(x)
            if mode == "Test":
                all_preds.extend(pred.argmax(1).cpu().numpy())
                all_targets.extend(y.cpu().numpy())
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

    test_loss /= num_batches
    total_losses[1].append(test_loss)
    test_accuracy = correct / size  # Calculate accuracy
    total_accuracies[1].append(test_accuracy)
    print(f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n")


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader, model, criterion, optimizer)
    test(val_dataloader, model, criterion, mode="Val")
    lr = adjust_learning_rate(optimizer, t, learning_rate)
    #print(torch.optim.lr_scheduler.CyclicLR.get_last_lr(scheduler))


# Convert each tensor in the list to a NumPy array
train_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[0]]
test_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[1]]

train_acuuracies_np = [accuracy for accuracy in total_accuracies[0]]
test_acuuracies_np = [accuracy for accuracy in total_accuracies[1]]

def plot_confusion_matrix(conf_matrix):
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cbar=False, xticklabels=keep_stanford40, yticklabels=keep_stanford40)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.savefig("Plots/confusion_matrix_test_train+val.png")

def plot_losses(train_losses_np, test_losses_np):
    plt.figure()
    plt.plot(train_losses_np, label='Train Loss')
    plt.plot(test_losses_np, label='Val Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title(f'Training and Validation Loss GoogleNet Stanford 40')
    plt.legend()
    plt.savefig(f"Plots/GoogleNet_Stanford40_loss.png")

def plot_accuracies(train_acuuracies_np, test_acuuracies_np):
    plt.figure()
    plt.plot(train_acuuracies_np, label='Train Accuracy')
    plt.plot(test_acuuracies_np, label='Val Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title(f'Training and Validation Accuracy GoogleNet Stanford 40')
    plt.legend()
    plt.savefig(f"Plots/GoogleNet_Stanford40_accuracy.png")


# Save the model weights
torch.save(model.state_dict(), f'Models/GoogleNet_Stanford40_weights.pth')

# Plot losses
plot_losses(train_losses_np, test_losses_np)

# Plot accuracies
plot_accuracies(train_acuuracies_np, test_acuuracies_np)
#
#
#
test(test_dataloader, model, criterion, mode="Test")
#
#
confusion_matrix = confusion_matrix(all_targets, all_preds)

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)