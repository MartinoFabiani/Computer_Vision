import os
import patoolib
import glob
from collections import Counter
from torchvision import datasets, transforms
import cv2 as cv
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import torchkeras
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
import torch
# Extract relevant classes
keep_hmdb51 = ["clap", "climb", "drink", "jump", "pour", "ride_bike", "ride_horse",
               "run", "shoot_bow", "smoke", "throw", "wave"]

### This processing step assumes video_data folder exists and is done at the start once
#for files in os.listdir('video_data'):
#    foldername = files.split('.')[0]
#    if foldername in keep_hmdb51:
#      # extract only the relevant classes for the assignment.
#      os.system("mkdir -p video_data/" + foldername)
#      patoolib.extract_archive(f"video_data/{files}", outdir=f"video_data/{foldername}")

# data files preprocessing and splitting train from test files and labels
TRAIN_TAG, TEST_TAG = 1, 2
train_files, test_files = [], []
train_labels, test_labels = [], []
split_pattern_name = f"*test_split1.txt"
split_pattern_path = os.path.join('test_train_splits/testTrainMulti_7030_splits', split_pattern_name)
annotation_paths = glob.glob(split_pattern_path)
for filepath in annotation_paths:
    class_name = ('_'.join(filepath.split('/')[-1].split('_')[:-2])).split('\\')[1]
    if class_name not in keep_hmdb51:
        continue  # skipping the classes that we won't use.
    with open(filepath) as fid:
        lines = fid.readlines()
    for line in lines:
        video_filename, tag_string = line.split()
        tag = int(tag_string)
        if tag == TRAIN_TAG:
            train_files.append(video_filename)
            train_labels.append(class_name)
        elif tag == TEST_TAG:
            test_files.append(video_filename)
            test_labels.append(class_name)

# function to extract the middle frame of the given video
def extract_middle_frame(video_path):
    # Open the video file
    cap = cv.VideoCapture(video_path)
    
    # Get the total number of frames
    total_frames = int(cap.get(cv.CAP_PROP_FRAME_COUNT))
    # Calculate the middle frame index
    middle_frame_index = total_frames // 2
    
    # Set the frame index to the middle frame
    cap.set(cv.CAP_PROP_POS_FRAMES, middle_frame_index)
    
    # Read the middle frame
    ret, frame = cap.read()
    
    # Release the video capture object
    cap.release()
    
    return frame

action_to_index = {action: index for index, action in enumerate(keep_hmdb51)}
# Replace class names with numbers
train_labels = [action_to_index[label] for label in train_labels]
test_labels = [action_to_index[label] for label in test_labels]

# Define a transform to convert 
# the image to torch tensor 
preprocess = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


def load_data(data_files, data_labels):
    data = []
    indx = 0
    # Iterate through each file in the directory
    for action_dir in os.listdir('video_data'):
        action_vids = os.path.join(f'video_data/{action_dir}', action_dir)
        for vid in os.listdir(action_vids):
            if vid.endswith(".avi") and indx < len(data_labels) and vid in data_files:
                video_path = os.path.join(action_vids, vid)
                label = data_labels[indx]
                # Extract middle frame
                img = extract_middle_frame(video_path)
                img = Image.fromarray(img)
                tensor = preprocess(img)
                tensor_label = (tensor, label)
                data.append(tensor_label)
                indx += 1
    return data


dataset_train = load_data(train_files, train_labels)
dataset_test = load_data(test_files, test_labels)

dataset_train, dataset_val = train_test_split(dataset_train, test_size=0.1, random_state=0)

# load the different datasets into dataloaders
train_dataloader = DataLoader(dataset_train, batch_size=32, shuffle=True)
val_dataloader = DataLoader(dataset_val, batch_size=32, shuffle=False)
test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)

model = torch.hub.load('pytorch/vision:v0.10.0', 'googlenet', pretrained=True)

# Modify the fully connected layer
num_ftrs = model.fc.in_features
model.fc = torch.nn.Sequential(
    torch.nn.Linear(num_ftrs, 12),
    torch.nn.Softmax(dim=1),
)
model.load_state_dict(torch.load('Models/GoogleNet_Stanford40_weights.pth'))
#torchkeras.summary(model, input_shape=(3,224,224))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)
#scheduler = torch.optim.lr_scheduler.CyclicLR(optimizer, base_lr=0.0001, max_lr=0.001, step_size_up=5, step_size_down=5, mode="triangular2", cycle_momentum=False)

learning_rates = []
learning_rate = 0.0001

# half the learning rate every 5 epochs for better learning
def adjust_learning_rate(optimizer, epoch, lr):
    lr = lr * (0.5 ** (epoch // 5))
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    learning_rates.append(lr)
    return lr

epochs = 25


total_accuracies = [[], []]
total_losses = [[], []]

# standard train function where the model weights get updated
def train(dataloader, model, criterion, optimizer):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)

        pred = model(x)
        loss = criterion(pred, y)

        train_loss += criterion(pred, y)
        correct += (pred.argmax(1) == y).sum().item()

        loss.backward()
        optimizer.step()
        #learning_rates.append(scheduler.get_last_lr()[0])
        #scheduler.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[0].append(train_loss)
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[0].append(train_accuracy)
    print(f"Train Error: \n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f} \n")

all_preds = []
all_targets = []

# standard test function which can be used for validation and testing
def test(dataloader, model, criterion, mode="Val"):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            pred = model(x)
            if mode == "Test":
                all_preds.extend(pred.argmax(1).cpu().numpy())
                all_targets.extend(y.cpu().numpy())
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

    test_loss /= num_batches
    total_losses[1].append(test_loss)
    test_accuracy = correct / size  # Calculate accuracy
    total_accuracies[1].append(test_accuracy)
    print(f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n")


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader, model, criterion, optimizer)
    test(val_dataloader, model, criterion, mode="Val")
    lr = adjust_learning_rate(optimizer, t, learning_rate)


# Convert each tensor in the list to a NumPy array
train_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[0]]
test_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[1]]

train_acuuracies_np = [accuracy for accuracy in total_accuracies[0]]
test_acuuracies_np = [accuracy for accuracy in total_accuracies[1]]

def plot_confusion_matrix(conf_matrix):
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cbar=False, xticklabels=keep_hmdb51, yticklabels=keep_hmdb51)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.savefig("Plots/confusion_matrix_HDMB51.png")

def plot_losses(train_losses_np, test_losses_np):
    plt.figure()
    plt.plot(train_losses_np, label='Train Loss')
    plt.plot(test_losses_np, label='Val Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title(f'Training and Validation Loss GoogleNet HDMB51')
    plt.legend()
    plt.savefig(f"Plots/GoogleNet_HDMB51_loss.png")

def plot_accuracies(train_acuuracies_np, test_acuuracies_np):
    plt.figure()
    plt.plot(train_acuuracies_np, label='Train Accuracy')
    plt.plot(test_acuuracies_np, label='Val Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title(f'Training and Validation Accuracy GoogleNet HDMB51')
    plt.legend()
    plt.savefig(f"Plots/GoogleNet_HDMB51_accuracy.png")

def plot_cyclical_learning_rates(learning_rates):
    epochs = len(learning_rates)
    plt.figure(figsize=(10, 5))
    plt.plot(range(1, epochs + 1), learning_rates, label="Learning Rate")
    plt.title("Cyclical Learning Rate")
    plt.xlabel("Train Iteration")
    plt.ylabel("Learning Rate")
    plt.xticks(range(1, epochs + 1))
    plt.grid(True)
    plt.legend()
    plt.savefig("Plots/cyclical_learning_rate_plot.png")

#plot_cyclical_learning_rates(learning_rates)
# Save the model weights
torch.save(model.state_dict(), f'Models/GoogleNet_HDMB510_weights.pth')

# Plot losses
plot_losses(train_losses_np, test_losses_np)

# Plot accuracies
plot_accuracies(train_acuuracies_np, test_acuuracies_np)



test(test_dataloader, model, criterion, mode="Test")


confusion_matrix = confusion_matrix(all_targets, all_preds)

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)