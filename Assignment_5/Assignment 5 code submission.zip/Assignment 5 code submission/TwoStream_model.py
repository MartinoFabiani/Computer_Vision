import torch
from torch import nn
import torchkeras

class OpticalFlowNet(nn.Module):
    def __init__(self, num_classes, stack_size):
        super(OpticalFlowNet, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=stack_size*2, out_channels=32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=2, stride=2, padding=0)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=4)

    def forward(self, x):
        # Adjust dimensions for convolutional layers
        x = x.permute(0, 4, 1, 2, 3)  # Shape: (32, 8, 224, 224, 2) -> (32, 2, 8, 224, 224)
        x = x.reshape((x.size(0), 8*2, 224, 224))
        x = torch.relu(self.conv1(x))
        x = self.pool1(x)
        x = torch.relu(self.conv2(x))
        x = self.pool1(x)
        x = torch.relu(self.conv3(x))
        x = self.pool2(x)

        return x


class TwoStreamNetwork(torch.nn.Module):
    def __init__(self, frame_model, optical_flow_model, num_classes):
        super(TwoStreamNetwork, self).__init__()
        self.frame_model = frame_model
        self.optical_flow_model = optical_flow_model
        self.conv = torch.nn.Conv2d(in_channels=256, out_channels=256, kernel_size=1, stride=1, padding=0)
        self.pool = torch.nn.MaxPool2d(kernel_size=2, stride=2)
        self.flatten = torch.nn.Flatten()
        self.linear = torch.nn.Linear(2304,64)
        self.fc = torch.nn.Linear(64, num_classes)

    def forward(self, frame_inputs, optical_flow_inputs):
        frame_features = self.frame_model(frame_inputs)
        optical_flow_features = self.optical_flow_model(optical_flow_inputs)

        # Concatenate the features from both branches
        merged_features = torch.cat((frame_features, optical_flow_features), dim=1)

        output = torch.relu(self.conv(merged_features))
        output = self.pool(output)
        output = self.flatten(output)
        output = self.linear(output)

        # Final fully connected layer for classification
        output = self.fc(output)
        output = torch.nn.functional.softmax(output, dim=1)
        return output
    