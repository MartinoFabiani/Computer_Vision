import glob
import os
import pickle
import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
from torch import nn
import torchkeras
from PIL import Image
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms

# Extract relevant classes
keep_hmdb51 = [
    "clap",
    "climb",
    "drink",
    "jump",
    "pour",
    "ride_bike",
    "ride_horse",
    "run",
    "shoot_bow",
    "smoke",
    "throw",
    "wave",
]

# optical flow size of stacked frames
stack_size = 8
num_classes = 12

# data files preprocessing and splitting train from test files and labels
TRAIN_TAG, TEST_TAG = 1, 2
train_files, test_files = [], []
train_labels, test_labels = [], []
split_pattern_name = f"*test_split1.txt"
split_pattern_path = os.path.join(
    "test_train_splits/testTrainMulti_7030_splits", split_pattern_name
)
annotation_paths = glob.glob(split_pattern_path)
for filepath in annotation_paths:
    class_name = ("_".join(filepath.split("/")[-1].split("_")[:-2])).split("\\")[1]
    if class_name not in keep_hmdb51:
        continue  # skipping the classes that we won't use.
    with open(filepath) as fid:
        lines = fid.readlines()
    for line in lines:
        video_filename, tag_string = line.split()
        tag = int(tag_string)
        if tag == TRAIN_TAG:
            train_files.append(video_filename)
            train_labels.append(class_name)
        elif tag == TEST_TAG:
            test_files.append(video_filename)
            test_labels.append(class_name)


action_to_index = {action: index for index, action in enumerate(keep_hmdb51)}

# Replace class names with numbers
train_labels = [action_to_index[label] for label in train_labels]
test_labels = [action_to_index[label] for label in test_labels]

# function to extract the first frames according to the stack size and caclulate a dense optical flow
def extract_optical_flow(video_path, stack_size):
    cap = cv.VideoCapture(video_path)
    ret, prev_frame = cap.read()
    prev_frame = cv.resize(prev_frame, (224, 224))
    prev_gray = cv.cvtColor(prev_frame, cv.COLOR_BGR2GRAY)
    flows = []
    stack_count = 0
    while True:
        ret, next_frame = cap.read()
        if not ret or stack_count == stack_size:
            break
        next_frame = cv.resize(next_frame, (224, 224))
        next_gray = cv.cvtColor(next_frame, cv.COLOR_BGR2GRAY)
        flow = cv.calcOpticalFlowFarneback(
            prev_gray, next_gray, None, 0.5, 3, 15, 3, 5, 1.2, 0
        )
        flows.append(flow)
        prev_gray = next_gray
        stack_count += 1
    cap.release()
    return np.array(flows)

# load optical flow and label in a way similar to pytorch Dataset
def load_data(data_files, data_labels):
    data = []
    os.makedirs("optical_flow", exist_ok=True)
    indx = 0
    for action_dir in os.listdir("video_data"):
        action_vids = os.path.join(f"video_data/{action_dir}", action_dir)
        for vid in os.listdir(action_vids):
            if vid.endswith(".avi") and indx < len(data_labels) and vid in data_files:
                video_path = os.path.join(action_vids, vid)
                label = data_labels[indx]
                # Verify if the pickles alreay exist
                pickle_file_path = f"optical_flow/{action_dir}_{indx}.pkl"
                if os.path.exists(pickle_file_path):
                    with open(pickle_file_path, "rb") as f:
                        optical_flow = pickle.load(f)
                else:
                    optical_flow = extract_optical_flow(video_path, stack_size)
                    # save the optical flow
                    with open(pickle_file_path, "wb") as f:
                        pickle.dump(optical_flow, f)

                optical_flow_tensor = torch.tensor(
                    optical_flow, dtype=torch.float32
                )

                data.append((optical_flow_tensor, label))
                indx += 1

    return data


dataset_train = load_data(train_files, train_labels)
dataset_test = load_data(test_files, test_labels)
dataset_train, dataset_val = train_test_split(
    dataset_train, test_size=0.1, random_state=0
)

# load the different datasets into dataloaders
train_dataloader = DataLoader(dataset_train, batch_size=32, shuffle=True)
val_dataloader = DataLoader(dataset_val, batch_size=32, shuffle=False)
test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)

# Define your neural network architecture
class OpticalFlowNet(nn.Module):
    def __init__(self, num_classes):
        super(OpticalFlowNet, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=stack_size*2, out_channels=32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.flatten = nn.Flatten()
        self.fc1 = nn.LazyLinear(256)  # Adjusted based on input size
        self.fc2 = nn.Linear(256, num_classes)
        self.dropout = nn.Dropout(0.1)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        # Adjust dimensions for convolutional layers
        x = x.permute(0, 4, 1, 2, 3)  # Shape: (32, 8, 224, 224, 2) -> (32, 2, 8, 224, 224)
        x = x.reshape((x.size(0), stack_size*2, 224, 224))
        x = torch.relu(self.conv1(x))
        x = self.pool(x)
        x = torch.relu(self.conv2(x))
        x = self.pool(x)
        x = self.flatten(x)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.dropout(x)
        x = self.softmax(x)

        return x


model = OpticalFlowNet(num_classes=12)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)


criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)


learning_rates = []
learning_rate = 0.0001


# half the learning rate every 5 epochs for better learning
def adjust_learning_rate(optimizer, epoch, lr):
    lr = lr * (0.5 ** (epoch // 5))
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    learning_rates.append(lr)
    return lr


epochs = 25


total_accuracies = [[], []]
total_losses = [[], []]


# standard train function where the model weights get updated
def train(dataloader, model, criterion, optimizer):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)
        #x = x.permute(0, 3, 1, 2)

        pred = model(x)
        loss = criterion(pred, y)
        train_loss += criterion(pred, y)
        correct += (pred.argmax(1) == y).sum().item()

        loss.backward()
        optimizer.step()
        # scheduler.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[0].append(train_loss)
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[0].append(train_accuracy)
    print(
        f"Train Error: \n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f} \n"
    )


all_preds = []
all_targets = []


# standard test function which can be used for validation and testing
def test(dataloader, model, criterion, mode="Val"):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            #x = x.permute(0, 3, 1, 2)
            pred = model(x)
            if mode == "Test":
                all_preds.extend(pred.argmax(1).cpu().numpy())
                all_targets.extend(y.cpu().numpy())
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

    test_loss /= num_batches
    total_losses[1].append(test_loss)
    test_accuracy = correct / size  # Calculate accuracy
    total_accuracies[1].append(test_accuracy)
    print(
        f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n"
    )


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader, model, criterion, optimizer)
    test(val_dataloader, model, criterion, mode="Val")
    lr = adjust_learning_rate(optimizer, t, learning_rate)
    # print(torch.optim.lr_scheduler.CyclicLR.get_last_lr(scheduler))


# Convert each tensor in the list to a NumPy array
train_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[0]]
test_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[1]]

train_acuuracies_np = [accuracy for accuracy in total_accuracies[0]]
test_acuuracies_np = [accuracy for accuracy in total_accuracies[1]]


def plot_confusion_matrix(conf_matrix):
    plt.figure(figsize=(12, 12))
    sns.heatmap(
        conf_matrix,
        annot=True,
        fmt="d",
        cbar=False,
        xticklabels=keep_hmdb51,
        yticklabels=keep_hmdb51,
    )
    plt.xlabel("Predicted Labels")
    plt.ylabel("True Labels")
    plt.title("Confusion Matrix")
    plt.savefig("Plots/confusion_matrix_optical_flow.png")


def plot_losses(train_losses_np, test_losses_np):
    plt.figure()
    plt.plot(train_losses_np, label="Train Loss")
    plt.plot(test_losses_np, label="Val Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Training and Validation Loss HDMB51 optical flow")
    plt.legend()
    plt.savefig(f"Plots/HDMB51_optical_flow_loss.png")


def plot_accuracies(train_acuuracies_np, test_acuuracies_np):
    plt.figure()
    plt.plot(train_acuuracies_np, label="Train Accuracy")
    plt.plot(test_acuuracies_np, label="Val Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title(f"Training and Validation Accuracy HDMB51 optical flow")
    plt.legend()
    plt.savefig(f"Plots/HDMB51_optical_flow_accuracy.png")


# Save the model weights
torch.save(model.state_dict(), f"Models/GoogleNet_HDMB510_opticalflow_weights.pth")

# Plot losses
plot_losses(train_losses_np, test_losses_np)

# Plot accuracies
plot_accuracies(train_acuuracies_np, test_acuuracies_np)


test(test_dataloader, model, criterion, mode="Test")


confusion_matrix = confusion_matrix(all_targets, all_preds)

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)
