import glob
import os
import pickle
from collections import Counter

import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import patoolib
import seaborn as sns
import torch
import torchkeras
from PIL import Image
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from torchvision import datasets, transforms
from TwoStream_model import TwoStreamNetwork, OpticalFlowNet

# Extract relevant classes
keep_hmdb51 = ["clap","climb","drink","jump","pour","ride_bike","ride_horse","run","shoot_bow","smoke","throw","wave"]

stack_size = 8
num_classes = 12

# data files preprocessing and splitting train from test files and labels
TRAIN_TAG, TEST_TAG = 1, 2
train_files, test_files = [], []
train_labels, test_labels = [], []
split_pattern_name = f"*test_split1.txt"
split_pattern_path = os.path.join(
    "test_train_splits/testTrainMulti_7030_splits", split_pattern_name
)
annotation_paths = glob.glob(split_pattern_path)
for filepath in annotation_paths:
    class_name = ("_".join(filepath.split("/")[-1].split("_")[:-2])).split("\\")[1]
    if class_name not in keep_hmdb51:
        continue  # skipping the classes that we won't use.
    with open(filepath) as fid:
        lines = fid.readlines()
    for line in lines:
        video_filename, tag_string = line.split()
        tag = int(tag_string)
        if tag == TRAIN_TAG:
            train_files.append(video_filename)
            train_labels.append(class_name)
        elif tag == TEST_TAG:
            test_files.append(video_filename)
            test_labels.append(class_name)


action_to_index = {action: index for index, action in enumerate(keep_hmdb51)}

# Replace class names with numbers
train_labels = [action_to_index[label] for label in train_labels]
test_labels = [action_to_index[label] for label in test_labels]


preprocess = transforms.Compose(
    [
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ]
)

def extract_middle_frame(video_path):
    # Open the video file
    cap = cv.VideoCapture(video_path)
    
    # Get the total number of frames
    total_frames = int(cap.get(cv.CAP_PROP_FRAME_COUNT))
    
    # Calculate the middle frame index
    middle_frame_index = total_frames // 2
    
    # Set the frame index to the middle frame
    cap.set(cv.CAP_PROP_POS_FRAMES, middle_frame_index)
    
    # Read the middle frame
    ret, frame = cap.read()
    
    # Release the video capture object
    cap.release()
    
    return frame


def extract_optical_flow(video_path, stack_size):
    cap = cv.VideoCapture(video_path)
    ret, prev_frame = cap.read()
    prev_frame = cv.resize(prev_frame, (224, 224))
    prev_gray = cv.cvtColor(prev_frame, cv.COLOR_BGR2GRAY)
    flows = []
    stack_count = 0
    while True:
        ret, next_frame = cap.read()
        if not ret or stack_count == stack_size:
            break
        next_frame = cv.resize(next_frame, (224, 224))
        next_gray = cv.cvtColor(next_frame, cv.COLOR_BGR2GRAY)
        flow = cv.calcOpticalFlowFarneback(
            prev_gray, next_gray, None, 0.5, 3, 15, 3, 5, 1.2, 0
        )
        flows.append(flow)
        prev_gray = next_gray
        stack_count += 1
    cap.release()
    return np.array(flows)


def load_data_optical_flow(data_files, data_labels):
    data = []
    os.makedirs("optical_flow", exist_ok=True)
    indx = 0
    for action_dir in os.listdir("video_data"):
        action_vids = os.path.join(f"video_data/{action_dir}", action_dir)
        for vid in os.listdir(action_vids):
            if vid.endswith(".avi") and indx < len(data_labels) and vid in data_files:
                video_path = os.path.join(action_vids, vid)
                label = data_labels[indx]
                # Verify if the pickles alreay exist
                pickle_file_path = f"optical_flow/{action_dir}_{indx}.pkl"
                if os.path.exists(pickle_file_path):
                    with open(pickle_file_path, "rb") as f:
                        optical_flow = pickle.load(f)
                else:
                    optical_flow = extract_optical_flow(video_path, stack_size)
                    # save the optical flow
                    with open(pickle_file_path, "wb") as f:
                        pickle.dump(optical_flow, f)

                optical_flow_tensor = torch.tensor(
                    optical_flow, dtype=torch.float32
                )

                data.append((optical_flow_tensor, label))
                indx += 1

    return data

def load_data_frames(data_files, data_labels):
    data = []
    indx = 0
    # Iterate through each file in the directory
    for action_dir in os.listdir('video_data'):
        action_vids = os.path.join(f'video_data/{action_dir}', action_dir)
        for vid in os.listdir(action_vids):
            if vid.endswith(".avi") and indx < len(data_labels) and vid in data_files:
                video_path = os.path.join(action_vids, vid)
                label = data_labels[indx]
                # Extract middle frame
                img = extract_middle_frame(video_path)
                img = Image.fromarray(img)
                tensor = preprocess(img)
                tensor_label = (tensor, label)
                data.append(tensor_label)
                indx += 1
    return data


dataset_train_frames = load_data_frames(train_files, train_labels)
dataset_test_frames = load_data_frames(test_files, test_labels)

dataset_train_frames, dataset_val_frames = train_test_split(
    dataset_train_frames, test_size=0.1, random_state=0
)

dataset_train_optical_flow = load_data_optical_flow(train_files, train_labels)
dataset_test_optical_flow = load_data_optical_flow(test_files, test_labels)


dataset_train_optical_flow, dataset_val_optical_flow = train_test_split(
    dataset_train_optical_flow, test_size=0.1, random_state=0
)

# load the different datasets into dataloaders
train_dataloader_frames = DataLoader(dataset_train_frames, batch_size=32, shuffle=True)
val_dataloader_frames = DataLoader(dataset_val_frames, batch_size=32, shuffle=False)
test_dataloader_frames = DataLoader(dataset_test_frames, batch_size=32, shuffle=False)

train_dataloader_optical_flow = DataLoader(dataset_train_optical_flow, batch_size=32, shuffle=True)
val_dataloader_optical_flow = DataLoader(dataset_val_optical_flow, batch_size=32, shuffle=False)
test_dataloader_optical_flow = DataLoader(dataset_test_optical_flow, batch_size=32, shuffle=False)

# INITIALIZATION OF PRETRAINED MODELS
frame_model = torch.hub.load("pytorch/vision:v0.10.0", "googlenet", pretrained=True)
frame_model.load_state_dict(torch.load('Models/GoogleNet_HDMB51_weights.pth'), strict=False)
# delete the last 3 layers after the final convolutional layer and add another convolutional layer to adjust the output shape
frame_model = torch.nn.Sequential(*list(frame_model.children())[:-3])
frame_model.add_module(
    "additional_conv", torch.nn.Conv2d(1024, 128, kernel_size=1, stride=1, padding=0)
)

optical_flow_model = OpticalFlowNet(12,8)
optical_flow_model.load_state_dict(torch.load("Models/HDMB510_opticalflow_weights.pth"),strict=False)

# two-stream network takes both networks as input
model = TwoStreamNetwork(frame_model, optical_flow_model, num_classes)

#torchkeras.summary(model=model, input_shape=[(3,224,224),(16,224,224)])
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)


criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)


learning_rates = []
learning_rate = 0.0001


# half the learning rate every 5 epochs for better learning
def adjust_learning_rate(optimizer, epoch, lr):
    lr = lr * (0.5 ** (epoch // 5))
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    learning_rates.append(lr)
    return lr


epochs = 25


total_accuracies = [[], []]
total_losses = [[], []]


def train(dataloader_frames, dataloader_optical_flow, model, criterion, optimizer):
    size = len(dataloader_frames.dataset)
    num_batches = len(dataloader_frames)
    model.train()
    train_loss, correct = 0, 0
    for (frame_data, frame_labels), (optical_flow_data, optical_flow_labels) in zip(dataloader_frames, dataloader_optical_flow):
        frame_data, frame_labels = frame_data.to(device), frame_labels.to(device)
        optical_flow_data, optical_flow_labels = optical_flow_data.to(device), optical_flow_labels.to(device)
        pred = model(frame_data, optical_flow_data)
        loss = criterion(pred, frame_labels)

        train_loss += loss.item()
        correct += (pred.argmax(1) == frame_labels).sum().item()

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[0].append(train_loss)
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[0].append(train_accuracy)
    print(f"Train Error:\n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f}\n")


all_preds = []
all_targets = []


# standard test function which can be used for validation and testing
def test(dataloader_frames, dataloader_optical_flow, model, criterion, mode="Val"):
    size = len(dataloader_frames.dataset)
    num_batches = len(dataloader_frames)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for (frame_data, frame_labels), (optical_flow_data, optical_flow_labels) in zip(dataloader_frames, dataloader_optical_flow):
            frame_data, frame_labels = frame_data.to(device), frame_labels.to(device)
            optical_flow_data, optical_flow_labels = optical_flow_data.to(device), optical_flow_labels.to(device)

            pred = model(frame_data, optical_flow_data)
            if mode == "Test":
                all_preds.extend(pred.argmax(1).cpu().numpy())
                all_targets.extend(frame_labels.cpu().numpy())
            test_loss += criterion(pred, frame_labels)
            correct += (pred.argmax(1) == frame_labels).sum().item()

    test_loss /= num_batches
    total_losses[1].append(test_loss)
    test_accuracy = correct / size  # Calculate accuracy
    total_accuracies[1].append(test_accuracy)
    print(f"Test Error:\n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f}\n")


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader_frames, train_dataloader_optical_flow, model, criterion, optimizer)
    test(val_dataloader_frames, val_dataloader_optical_flow, model, criterion, mode="Val")
    lr = adjust_learning_rate(optimizer, t, learning_rate)


# Convert each tensor in the list to a NumPy array
train_losses_np = torch.tensor(total_losses[0], device = 'cpu')
test_losses_np = torch.tensor(total_losses[1], device = 'cpu')
train_acuuracies_np = [accuracy for accuracy in total_accuracies[0]]
test_acuuracies_np = [accuracy for accuracy in total_accuracies[1]]

def plot_confusion_matrix(conf_matrix):
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, annot=True, fmt="d", cbar=False, xticklabels=keep_hmdb51, yticklabels=keep_hmdb51)
    plt.xlabel("Predicted Labels")
    plt.ylabel("True Labels")
    plt.title("Confusion Matrix")
    plt.savefig("Plots/confusion_matrix_TwoStream.png")


def plot_losses(train_losses_np, test_losses_np):
    plt.figure()
    plt.plot(train_losses_np, label="Train Loss")
    plt.plot(test_losses_np, label="Val Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(f"Training and Validation Loss Two Stream Network")
    plt.legend()
    plt.savefig(f"Plots/TwoStream_loss.png")


def plot_accuracies(train_acuuracies_np, test_acuuracies_np):
    plt.figure()
    plt.plot(train_acuuracies_np, label="Train Accuracy")
    plt.plot(test_acuuracies_np, label="Val Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title(f"Training and Validation Accuracy Two Stream Network")
    plt.legend()
    plt.savefig(f"Plots/TwoStream_accuracy.png")


# Save the model weights
torch.save(model.state_dict(), f"Models/TwoStream_weights.pth")

# Plot losses
plot_losses(train_losses_np, test_losses_np)

# Plot accuracies
plot_accuracies(train_acuuracies_np, test_acuuracies_np)


test(test_dataloader_frames, test_dataloader_optical_flow, model, criterion, mode="Test")


confusion_matrix = confusion_matrix(all_targets, all_preds)

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)
