import matplotlib.pyplot as plt
import numpy as np
import torch
import torchkeras
from torch.utils.data import DataLoader, Dataset, random_split
from torchvision import datasets
from torchvision.transforms import ToTensor

from choice_multioutput import LeNet5

dataset_train = datasets.FashionMNIST(root="data", train=True, transform=ToTensor())
dataset_test = datasets.FashionMNIST(root="data", train=False, transform=ToTensor())

dataset_train, dataset_val = random_split(dataset_train, [0.8, 0.2])

train_dataloader = DataLoader(dataset_train, batch_size=32, shuffle=True)
val_dataloader = DataLoader(dataset_val, batch_size=32, shuffle=False)
test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)

model = LeNet5()
torchkeras.summary(model, input_shape=(1, 28, 28))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

epochs = 15

total_accuracies = [[] for _ in range(7)]
total_losses = [[] for _ in range(7)]


def train(dataloader, model, criterion, optimizer):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)

        pred, output1, output2, output3 = model(x)  # Ottieni gli output intermedi
        loss = criterion(pred, y)

        train_loss += criterion(pred, y)
        correct += (pred.argmax(1) == y).sum().item()

        # Calcola accuratezza e perdita su ciascun output aggiuntivo
        loss_output1 = criterion(output1, y)
        loss_output2 = criterion(output2, y)
        loss_output3 = criterion(output3, y)

        # Aggiungi perdite intermedie alle perdite totali
        total_losses[0].append(loss_output1.item())
        total_losses[1].append(loss_output2.item())
        total_losses[2].append(loss_output3.item())

        # Calcola accuratezza per ogni output intermedio
        accuracy_output1 = (output1.argmax(1) == y).sum().item() / len(y)
        accuracy_output2 = (output2.argmax(1) == y).sum().item() / len(y)
        accuracy_output3 = (output3.argmax(1) == y).sum().item() / len(y)

        # Aggiungi accuratezza intermedia alle accuratezze totali
        total_accuracies[0].append(accuracy_output1)
        total_accuracies[1].append(accuracy_output2)
        total_accuracies[2].append(accuracy_output3)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[3].append(train_loss.item())
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[3].append(train_accuracy)
    print(
        f"Output 1 Accuracy: {(100*accuracy_output1):>3f}%, Avg loss: {loss_output1:>8f} \n"
    )
    print(
        f"Output 2 Accuracy: {(100*accuracy_output2):>3f}%, Avg loss: {loss_output2:>8f} \n"
    )
    print(
        f"Output 3 Accuracy: {(100*accuracy_output3):>3f}%, Avg loss: {loss_output3:>8f} \n"
    )
    print(
        f"Train Error: \n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f} \n"
    )


def test(dataloader, model, criterion):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0

    # Inizializza le variabili per l'accuratezza e la perdita degli output intermedi
    output1_loss, output2_loss, output3_loss = 0, 0, 0
    output1_correct, output2_correct, output3_correct = 0, 0, 0

    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)

            pred, output1, output2, output3 = model(x)

            # Calcola la perdita e l'accuratezza per il modello principale
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

            # Calcola la perdita e l'accuratezza per ciascun output intermedio
            output1_loss += criterion(output1, y)
            output2_loss += criterion(output2, y)
            output3_loss += criterion(output3, y)

            output1_correct += (output1.argmax(1) == y).sum().item()
            output2_correct += (output2.argmax(1) == y).sum().item()
            output3_correct += (output3.argmax(1) == y).sum().item()

    # Calcola la perdita media e l'accuratezza per ciascun output intermedio
    output1_loss /= num_batches
    output2_loss /= num_batches
    output3_loss /= num_batches

    output1_accuracy = output1_correct / size
    output2_accuracy = output2_correct / size
    output3_accuracy = output3_correct / size

    # Aggiungi le perdite e le accuratezze degli output intermedi alle liste totali
    total_losses[4].append(output1_loss.item())
    total_losses[5].append(output2_loss.item())
    total_losses[6].append(output3_loss.item())

    total_accuracies[4].append(output1_accuracy)
    total_accuracies[5].append(output2_accuracy)
    total_accuracies[6].append(output3_accuracy)

    # Calcola la perdita e l'accuratezza complessiva del modello
    test_loss /= num_batches
    total_losses[1].append(test_loss.item())
    test_accuracy = correct / size
    total_accuracies[1].append(test_accuracy)
    print(
        f"Output 1 Test Error: \n Accuracy: {(100*output1_accuracy):>3f}%, Avg loss: {output1_loss:>8f} \n"
    )
    print(
        f"Output 2 Test Error: \n Accuracy: {(100*output2_accuracy):>3f}%, Avg loss: {output2_loss:>8f} \n"
    )
    print(
        f"Output 3 Test Error: \n Accuracy: {(100*output3_accuracy):>3f}%, Avg loss: {output3_loss:>8f} \n"
    )
    print(
        f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n"
    )


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader, model, criterion, optimizer)
    test(val_dataloader, model, criterion)


# Calcola le accuratezze medie per ogni output intermedio su tutte le epoche
output1_train_accuracy_avg = np.mean(total_accuracies[0])
output2_train_accuracy_avg = np.mean(total_accuracies[1])
output3_train_accuracy_avg = np.mean(total_accuracies[2])
output1_test_accuracy_avg = np.mean(total_accuracies[4])
output2_test_accuracy_avg = np.mean(total_accuracies[5])
output3_test_accuracy_avg = np.mean(total_accuracies[6])

# Converti le accuratezze medie in NumPy array
train_accuracies_np = np.array(
    [output1_train_accuracy_avg, output2_train_accuracy_avg, output3_train_accuracy_avg]
)
test_accuracies_np = np.array(
    [output1_test_accuracy_avg, output2_test_accuracy_avg, output3_test_accuracy_avg]
)

# Plot the accuracies
plt.plot(train_accuracies_np, label="Train Accuracy")
plt.plot(test_accuracies_np, label="Test Accuracy")
plt.xlabel("Output Intermedi")
plt.ylabel("Accuracy")
plt.title("Average Training and Test Accuracies")
plt.xticks(np.arange(3), ["Output 1", "Output 2", "Output 3"])
plt.legend()
plt.savefig("LeNet5_Average_Accuracies.png")


"""
# Convert each tensor in the list to a NumPy array
train_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[0]]
test_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[1]]

# Plot the losses
plt.plot(train_losses_np, label="Train Loss")
plt.plot(test_losses_np, label="Test Loss")
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Training and Test Losses")
plt.legend()
plt.savefig("LeNet5_4.0.png")
"""
