import matplotlib.pyplot as plt
import numpy as np
import torch
import torchkeras
from sklearn.manifold import TSNE
from torch.utils.data import DataLoader, Dataset, random_split
from torchvision import datasets
from torchvision.transforms import ToTensor

from LeNet5_5 import LeNet5

dataset_test = datasets.FashionMNIST(root="data", train=False, transform=ToTensor())

test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)


model = LeNet5()
model.load_state_dict(torch.load('Models/lenet5_5.0_weights.pth'))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)
model.eval()

# Lists to store fully connected layer outputs and corresponding labels
fc_layer_outputs = []
labels = []

# Iterate through the test dataset and extract fully connected layer outputs
with torch.no_grad():
    for images, targets in test_dataloader:
        images = images.to(device)
        # Pass images through the model to get the fully connected layer outputs
        fc_output = model(images)
        # Append fully connected layer outputs and labels to lists
        fc_layer_outputs.append(fc_output[:, :-1].cpu().numpy())  # Exclude the softmax layer output
        labels.append(targets.numpy())

# Concatenate the lists to get numpy arrays
fc_layer_outputs = np.concatenate(fc_layer_outputs, axis=0)
labels = np.concatenate(labels)

# Apply t-SNE to reduce dimensions
tsne = TSNE(n_components=2, random_state=42)
tsne_representation = tsne.fit_transform(fc_layer_outputs)

# Define class labels
class_labels = ['T-shirt/top', 'Trouser/pants', 'Pullover shirt', 'Dress', 'Coat', 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# Visualize t-SNE representation with class labels in legend
plt.figure(figsize=(10, 8))
for i in range(10):
    plt.scatter(
        tsne_representation[labels == i, 0],
        tsne_representation[labels == i, 1],
        label=class_labels[i],  # Use class labels
    )
plt.title("t-SNE Visualization of Fully Connected Layer Outputs (Before Softmax)")
plt.xlabel("t-SNE Component 1")
plt.ylabel("t-SNE Component 2")
plt.legend()
plt.savefig("Plots/t-SNE Visualization.png")