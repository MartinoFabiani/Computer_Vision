from torch import nn


class LeNet5(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(
            in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=2
        )
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv3 = nn.Conv2d(
            in_channels=16, out_channels=120, kernel_size=5, stride=1
        )
        self.relu3 = nn.ReLU()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(120, 84)
        self.fc2 = nn.Linear(84, 10)
        self.softmax = nn.Softmax(dim=1)

        # Output layer after the second convolution layer
        self.output_conv1 = nn.Linear(16 * 5 * 5, 10)
        # Output layer after the second pooling layer
        self.output_pool2 = nn.Linear(16 * 5 * 5, 10)
        # Output layer after the third convolution layer
        self.output_conv3 = nn.Linear(120, 10)

        # Initialize the weights with Kaiming Uniform
        self.init_weights()

    def init_weights(self):
        for layer in self.modules():
            if isinstance(layer, (nn.Linear, nn.Conv2d)):
                # Kaiming Uniform Initialization
                nn.init.kaiming_uniform_(
                    layer.weight, mode="fan_in", nonlinearity="relu"
                )
                if layer.bias is not None:
                    nn.init.constant_(layer.bias, 0)

    def forward(self, x):
        conv1_out = self.pool1(self.relu1(self.conv1(x)))
        conv2_out = self.pool2(self.relu2(self.conv2(conv1_out)))
        conv3_out = self.relu3(self.conv3(conv2_out))
        flattened = self.flatten(conv3_out)
        fc1_out = self.fc1(flattened)
        fc2_out = self.fc2(fc1_out)
        output1 = self.softmax(
            self.output_conv1(conv2_out.view(conv2_out.size(0), -1))
        )  # Output after conv2
        output2 = self.softmax(
            self.output_pool2(conv2_out.view(conv2_out.size(0), -1))
        )  # Output after pool2
        output3 = self.softmax(self.output_conv3(flattened))  # Output after conv3
        return fc2_out, output1, output2, output3
