import os

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import torch
import torchkeras
from PIL import Image
from torch.utils.data import DataLoader, Dataset, random_split
from torchvision import datasets
from torchvision.transforms import Compose, Resize, ToTensor
from sklearn.metrics import confusion_matrix

from LeNet5_5 import LeNet5

# create a custom Dataset class for FashionProducts
class FashionProducts(Dataset):
    def __init__(self, root, csv_file, transform=None):
        self.root = root
        self.data = pd.read_csv(csv_file)
        self.transform = transform
        
        # mapping labels to their corresponding digits
        self.label_map = {
            "T-shirt/top": 0,
            "Trouser": 1,
            "Pullover": 2,
            "Dress": 3,
            "Coat": 4,
            "Sandal": 5,
            "Shirt": 6,
            "Sneaker": 7,
            "Bag": 8,
            "Ankle boot": 9,
        }

        # basic transformation of just resizing and converting to tensor
        if transform is None:
            self.transform = Compose(
                [
                    Resize((28, 28)),
                    ToTensor(),
                ]
            )
        # possibility to add more transforms
        else:
            self.transform = Compose(
                [
                    Resize((28, 28)),
                    transform,
                ]
            )

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_name = os.path.join(self.root, f"{self.data.iloc[idx, 0]}.jpg")
        image = Image.open(img_name)
        label = self.data.iloc[idx, 1]
        label = self.label_map[label]

        if self.transform:
            image = self.transform(image)

        label_tensor = torch.tensor(label)
        if torch.cuda.is_available():
            label_tensor = label_tensor.cuda()

        return image, label

# create the dataset
new_dataset = FashionProducts(
    root="Fashion_Products_Images/data",
    csv_file="Fashion_Products_Images/fashion_proucts_filtered.csv",
    transform=ToTensor(),
)

# load the dataset
fashion_dataloader = DataLoader(new_dataset, batch_size=32, shuffle=False)


# load model and its saved parameters/weights
model = LeNet5()
model.load_state_dict(torch.load('Models/lenet5_5.0_weights.pth'))
torchkeras.summary(model, input_shape=(1, 28, 28))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

criterion = torch.nn.CrossEntropyLoss()

all_preds = []
all_targets = []
def test(dataloader, model, criterion):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            pred = model(x)
            all_preds.extend(pred.argmax(1).cpu().numpy())
            all_targets.extend(y.cpu().numpy())
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

    test_loss /= num_batches
    test_accuracy = correct / size  # Calculate accuracy
    print(f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n")

# test on the FashionProducts dataset
test(fashion_dataloader, model, criterion)

confusion_matrix = confusion_matrix(all_targets, all_preds)


def plot_confusion_matrix(conf_matrix):
        # Define category names
    categories = ['T-shirt/top', 'Trouser/pants', 'Pullover shirt', 'Dress', 'Coat',
                  'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cbar=False, xticklabels=categories, yticklabels=categories)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.savefig("Plots/confusion_matrix_FashionProducts.png")

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)