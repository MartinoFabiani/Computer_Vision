import numpy as np
from torch.utils.data import Dataset, random_split, DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
import torch
import torchkeras
from LeNet5_5 import LeNet5

model_number = 5

# load the dataset
dataset_train = datasets.FashionMNIST(root='data', train=True, transform=ToTensor())
dataset_test = datasets.FashionMNIST(root='data', train=False, transform=ToTensor())

# 80/20 train/validation split as per popular practice
dataset_train, dataset_val = random_split(dataset_train, [0.8, 0.2])

# load the different datasets into dataloaders
train_dataloader = DataLoader(dataset_train, batch_size=32, shuffle=True)
val_dataloader = DataLoader(dataset_val, batch_size=32, shuffle=False)
test_dataloader = DataLoader(dataset_test, batch_size=32, shuffle=False)

model = LeNet5()
#model.load_state_dict(torch.load('Models/lenet5_5.0_weights.pth'))
torchkeras.summary(model, input_shape=(1,28,28))
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
model.to(device)

criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)


learning_rates = []
learning_rate = 0.001

# half the learning rate every 5 epochs for better learning
def adjust_learning_rate(optimizer, epoch, lr):
    lr = lr * (0.5 ** (epoch // 5))
    for param_group in optimizer.param_groups:
        param_group["lr"] = lr
    learning_rates.append(lr)
    return lr


epochs = 15


total_accuracies = [[], []]
total_losses = [[], []]

# standard train function where the model weights get updated
def train(dataloader, model, criterion, optimizer):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.train()
    train_loss, correct = 0, 0
    for batch, (x, y) in enumerate(dataloader):
        x, y = x.to(device), y.to(device)

        pred = model(x)
        loss = criterion(pred, y)

        train_loss += criterion(pred, y)
        correct += (pred.argmax(1) == y).sum().item()

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    train_loss /= num_batches
    total_losses[0].append(train_loss)
    train_accuracy = correct / size  # Calculate accuracy
    total_accuracies[0].append(train_accuracy)
    print(f"Train Error: \n Accuracy: {(100*train_accuracy):>3f}%, Avg loss: {train_loss:>8f} \n")

all_preds = []
all_targets = []

# standard test function which can be used for validation and testing
def test(dataloader, model, criterion, mode="Val"):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            pred = model(x)
            if mode == "Test":
                all_preds.extend(pred.argmax(1).cpu().numpy())
                all_targets.extend(y.cpu().numpy())
            test_loss += criterion(pred, y)
            correct += (pred.argmax(1) == y).sum().item()

    test_loss /= num_batches
    total_losses[1].append(test_loss)
    test_accuracy = correct / size  # Calculate accuracy
    total_accuracies[1].append(test_accuracy)
    print(f"Test Error: \n Accuracy: {(100*test_accuracy):>3f}%, Avg loss: {test_loss:>8f} \n")


for t in range(epochs):
    print(f"Epoch {t+1}\n---------------------")
    train(train_dataloader, model, criterion, optimizer)
    #test(val_dataloader, model, criterion, mode="Val")
    lr = adjust_learning_rate(optimizer, t, learning_rate)


# Convert each tensor in the list to a NumPy array
train_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[0]]
test_losses_np = [loss.cpu().detach().numpy() for loss in total_losses[1]]

train_acuuracies_np = [accuracy for accuracy in total_accuracies[0]]
test_acuuracies_np = [accuracy for accuracy in total_accuracies[1]]

def plot_confusion_matrix(conf_matrix):
        # Define category names
    categories = ['T-shirt/top', 'Trouser/pants', 'Pullover shirt', 'Dress', 'Coat',
                  'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
    plt.figure(figsize=(12, 12))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cbar=False, xticklabels=categories, yticklabels=categories)
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')
    plt.title('Confusion Matrix')
    plt.savefig("Plots/confusion_matrix_test_train+val.png")

def plot_losses(train_losses_np, test_losses_np):
    plt.figure()
    plt.plot(train_losses_np, label='Train Loss')
    plt.plot(test_losses_np, label='Val Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title(f'Training and Validation Loss LeNet5 {model_number}.0')
    plt.legend()
    plt.savefig(f"Plots/LeNet5_{model_number}.0_loss.png")

def plot_accuracies(train_acuuracies_np, test_acuuracies_np):
    plt.figure()
    plt.plot(train_acuuracies_np, label='Train Accuracy')
    plt.plot(test_acuuracies_np, label='Val Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy')
    plt.title(f'Training and Validation Accuracy LeNet5 {model_number}.0')
    plt.legend()
    plt.savefig(f"Plots/LeNet5_{model_number}.0_accuracy.png")

def plot_lr():
    plt.figure(figsize=(8, 6))
    plt.plot(range(epochs), learning_rates, marker="o", linestyle="-")
    plt.xlabel("Epochs")
    plt.ylabel("Learning Rate")
    plt.title("Learning Rate over Epochs")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("Plots/learning_rate_over_time_LeNet5_1.png")

# Save the model weights
torch.save(model.state_dict(), f'Models/lenet5_{model_number}.0_train+val_weights.pth')

# Plot losses
plot_losses(train_losses_np, test_losses_np)

# Plot accuracies
plot_accuracies(train_acuuracies_np, test_acuuracies_np)

plot_lr()


test(test_dataloader, model, criterion, mode="Test")


confusion_matrix = confusion_matrix(all_targets, all_preds)

# Plot confusion matrix
plot_confusion_matrix(confusion_matrix)